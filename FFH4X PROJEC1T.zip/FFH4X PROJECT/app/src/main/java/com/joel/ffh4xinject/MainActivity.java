package com.joel.ffh4xinject;
 
import android.app.Activity;
import android.os.Bundle;
import android.content.Context;

public class MainActivity extends Activity { 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_main);
        H4x.Vendors(getApplicationContext(),/*"¢PRINCE_https://t.me/princeinjector¢KRISHAN OFFICIAL_https://t.me/KRISHNAOFFICIAL628"*/"¢prince_https//t.me/princeinjector¢KRISHAN official_https//t.me/KRISHNAOFFICIAL628");
        /*H4x.AlertaGolpe(getApplicationContext(),"");*/
        //H4x.CriarLogin(getApplicationContext(),"");
        H4x.Start(getApplicationContext());
         
        
    }
    public static boolean M(final Context context,final String u,final String p){
        FloaterHS.madherchod2 = "!USER_PRINCE!PASSWORD_1234!EXPIRE_30/12/2023!CREATE_08/07/2022!SELLER_PRINCE";
        FloaterHS.madherchod4 = ",TEXT_--------AIMBOT--------,SWITCH_ENABLE AIM_0,SWITCH_AIM AUTO_1,SWITCH_ENABLE AIM FOV_2,SEEKBAR_AIM FOV_360_0,SWITCH_AIM ON FIRE_3,SWITCH_AIM ON SCOPE_4,SWITCH_AIM ON CROUCH_5,SWITCH_ON FIRE MOVE_6,TEXT_--------ESP--------,SWITCH_ESP FIRE_7,SWITCH_ESP GRANDE_8,SWITCH_ESP ALRT_9,SWITCH_ESP LINE_10,SWITCH_ESP BOX_11,SWITCH_ESP NAME_23,SWITCH_PLAYER STATUS ESP_12,SWITCH_ESP BOT?_13,SEEKBAR_ESP COLOR_10_1,SWITCH_ESP MODERN_25,TEXT_--------FLY-------,SWITCH_ENABLE FLY_14,SEEKBAR_FLY PLAYER_50_2,SEEKBAR_FLY SEED_80_3,TEXT_-------TELEPORT------,SEEKBAR_TELEPORT RANGE_360_4,SWITCH_TELEPORT CAR_15,SWITCH_TELEPORT PLAYER_16,SWITCH_TELEPORT ON FIRE_17,SWITCH_TELEPORT ON CROUCH_18,TEXT_----------ACCOUNT SETTING---------,SWITCH_RESET GUEST_19,SWITCH_BYPASS BLACKLIST_20,TEXT_--------OTHER--------,SEEKBAR_CAMERA VIEW_6_5,SEEKBAR_PLAYER SPEED_4_6,SEEKBAR_RECOIL RATE_199_7,SWITCH_GHOST_22,SWITCH_FAST HEALTH + MOVE HEALTH_24,";
        
        return true;
    }
	
}
