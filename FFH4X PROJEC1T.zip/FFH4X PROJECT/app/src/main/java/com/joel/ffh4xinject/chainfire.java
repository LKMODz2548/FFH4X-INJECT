package com.joel.ffh4xinject;

import eu.chainfire.libsuperuser.Shell;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator; 
import java.util.List;
import java.lang.Object;
import android.widget.Toast;
import android.content.Context; 
import android.text.Html;

public class chainfire {
    final Context getApplicationContext;
    
    public static int Game(String pkg) {
        try {
            ArrayList arrayList = new ArrayList();
            Shell.PoolWrapper poolWrapper = Shell.Pool.SU;
            poolWrapper.run("(toolbox ps; toolbox ps -A; toybox ps; toybox ps -A) | grep \" " + pkg + "$\"", arrayList, null, false);
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                String Trim = ((String) iterator.next()).trim();
                while (Trim.contains("  ")) { 
                    Trim = Trim.replace("  ", " ");
                } 
                String[] Split = Trim.split(" "); 
                if (Split.length >= 2) {
                    return Integer.parseInt(Split[1]);
                }
            }
            return -1;
        } catch (Shell.ShellDiedException e) {
            e.printStackTrace();
            return -1;
        }
    }
    public static boolean Injector(String inject,String lib,String games,String n) {
        boolean[] booleans = {false};
        try { 
            String injector = inject;
            new File(injector).setExecutable(true);
            String payload_source = lib;
            String payload_dest = "/data/local/tmp/"+n;
            String context = "u:object_r:system_lib_file:s0";
            List<String> STDOUT = new ArrayList<>();
            Shell.Pool.SU.run("ls -lZ /system/lib/libandroid_runtime.so", STDOUT, null, false);
            for (String line : STDOUT) {
                if (line.contains(" u:object_r:") && line.contains(":s0 ")) {
                    context = line.substring(line.indexOf("u:object_r:"));
                    context = context.substring(0, context.indexOf(' '));
                }
            }
            Shell.Pool.SU.run(new String[] {"cp " + payload_source + " " + payload_dest, "chmod 777 " + payload_dest});
            int game = -1;
            while (game < 0) { game = Game(games); }
            if (game < 0) { return Boolean.FALSE; }

            Shell.Pool.SU.run((Object) String.format("%s %d %s", new Object[]{injector, Integer.valueOf(game), payload_dest}), booleans[0]);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
             //Toast.makeText(getApplicationContext, Html.fromHtml("NO ROOT : " + "<font color='red'>Failed to get libil2cpp.so"), Toast.LENGTH_LONG).show();
            return false;
        }
    }
 
       
        public chainfire(Context context) {
            getApplicationContext = context;
        }
}
