package com.joel.ffh4xinject;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context; 
import android.content.Intent;
import android.graphics.BitmapFactory; 
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable; 
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.app.Activity;   
import android.app.AlertDialog; 
import android.content.Context; 
import android.text.Html; 
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.widget.HorizontalScrollView;  
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.app.ActionBar.LayoutParams;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout; 
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.view.View;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Timer;
import java.util.TimerTask;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator; 
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import android.view.Gravity;
import android.net.Uri;
import android.content.SharedPreferences;
import android.annotation.SuppressLint;
import android.graphics.PorterDuff;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Base64;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.UUID;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.icu.util.Calendar;
import android.icu.text.SimpleDateFormat;
import android.content.SharedPreferences;
import android.os.Looper;
import android.graphics.Typeface;
import java.lang.invoke.WrongMethodTypeException;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.os.StrictMode;
import android.provider.Settings;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.HttpsURLConnection;
import java.security.Key;
import android.widget.RemoteViews;
import android.graphics.ColorFilter;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.widget.HorizontalScrollView;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_LEFT;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import android.content.res.ColorStateList;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.File;
import android.speech.tts.TextToSpeech;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import android.os.Binder;
import android.widget.ArrayAdapter;
import android.view.View;
import android.widget.AdapterView;
import com.joel.ffh4xinject.Esp2;
//import com.joel.ffh4xinject.chainfire;
import java.util.Locale;
import com.topjohnwu.superuser.Shell;
//import com.topjohnwu.superuser.internal.ShellTerminatedException;
import android.renderscript.Element;
import android.view.LayoutInflater;
import android.widget.Spinner;
import com.google.android.gms.common.api.Response;
public class FloaterHS  extends Service{
    public static String[] madherchod = null;
    public static String  madherchod2;
    public static String  injectType = "VIRTUAL";
    public static String[] madherchod3 = null;
    public static String  madherchod4;
    public static native void DrawOn(Esp2 espView, Canvas canvas);
    static native void Size(int num, float size); 
    native void AddTextC(int num, String Text,String out);
    native void Changes(int feature, int value);
    native boolean IsConnected();
    native String GetStr(int num, String Text,String out);
    //  native void Init(); 
    native int Init();
    native void Stop();
    native void Switch(int num, boolean flag);
    Esp2 EspOverLay;
    native String Icon();
    native String FUCK();
    FrameLayout Main; //= new FrameLayout(this);
    RelativeLayout R1;// = new RelativeLayout(this);
    RelativeLayout R2;//= new RelativeLayout(this);
    RelativeLayout R3; //= new RelativeLayout(this);
    LinearLayout L1,FUNCTION,heading; 
    LinearLayout option;              //= new LinearLayout(this);
    GradientDrawable DL1;//= new GradientDrawable();
    TextView T1; //=new TextView(this);
    TextView STATUS,S,ABI,Mod; //= new TextView(this);
    ScrollView  S1; //= new ScrollView(this);
    Button CLOSE;// = new Button(this);
    Button inject;
    Spinner Select;
    private ArrayList<String> Pass = new ArrayList<>();
   WindowManager.LayoutParams FLOATLAYOUT1, ESPLIST;
    WindowManager Window, EspWindow;
    @Override
    public void onCreate() { 
        super.onCreate();
        System.loadLibrary("FFH4X");
        EspOverLay = new Esp2(this);
        EspWindow = (WindowManager) getSystemService("window");
        DrawCanvas();
      
    }
    private int getLayoutType() {
        int LAYOUT_FLAG;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_TOAST;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        }
        return LAYOUT_FLAG;
    }

    private void DrawCanvas() {
        ESPLIST = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            getLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT);
        ESPLIST.gravity = Gravity.TOP | Gravity.START;
        ESPLIST.x = 0;
        ESPLIST.y = 100;
        EspWindow.addView(EspOverLay, ESPLIST);
    }
    private void f(final Context context){
        Main = new FrameLayout(context);
        R1 = new RelativeLayout(context);
        R2= new RelativeLayout(context);
        R3 = new RelativeLayout(context);
        L1 = new LinearLayout(context);
        option = new LinearLayout(context);
        DL1= new GradientDrawable();
        T1 =new TextView(context);
        STATUS = new TextView(context);
        S1 = new ScrollView(context);
        CLOSE = new Button(context);
        inject = new Button(context);
        S = new TextView(context);
        ABI = new TextView(context);
        Mod = new TextView(context);
        FUNCTION = new LinearLayout(context);
      //FLOATLAYOUT1=new WindowManager.LayoutParams();
        Main.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        R1.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        R2.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        R2.setVisibility(View.VISIBLE);
        final ImageView DarkIcon = new ImageView(this);
        DarkIcon.setLayoutParams(new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) 50, getResources().getDisplayMetrics());
        DarkIcon.getLayoutParams().height = applyDimension;
        DarkIcon.getLayoutParams().width = applyDimension;
        DarkIcon.setAlpha(200);
        DarkIcon.setScaleType(ImageView.ScaleType.FIT_XY);
      // Main.setBackgroundColor(Color.parseColor("#FF696969"));
       byte[] decode = Base64.decode(H4x.Icon, 0);
       DarkIcon.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
       // DarkIcon.setBackgroundResource(R.drawable.icone);
        ((ViewGroup.MarginLayoutParams) DarkIcon.getLayoutParams()).topMargin = convertDipToPixels(10);
        DarkIcon.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    R2.setVisibility(View.GONE);
                    L1.setVisibility(View.VISIBLE);
                }
            });
        final ImageView cm = new ImageView(this);
        cm.setLayoutParams(new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
        int applyDimension2 = (int) TypedValue.applyDimension(3, (float) 5, getResources().getDisplayMetrics());
        cm.getLayoutParams().height = applyDimension2;
        cm.getLayoutParams().width = applyDimension2;
        cm.setAlpha(200);
        cm.setScaleType(ImageView.ScaleType.FIT_START);
        byte[] decode1 = Base64.decode(H4x.Close, 0);
       // cm.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
       cm.setBackgroundResource(R.drawable.xh4x);
       ((ViewGroup.MarginLayoutParams) cm.getLayoutParams()).topMargin = convertDipToPixels(10);
        cm.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    Builder AlertaUpdate = new Builder(context);
                    AlertaUpdate.setTitle("Deseja Fechar ?");
                    AlertaUpdate.setCancelable(false);
                    //AlertaUpdate.setMessage("1 - Usuario não existe\n2 - Usuario ou Senha incorretos!\n3 - Não é o dono do Usuario");
                    AlertaUpdate.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dia, int which) {

                            }
                        });
                    AlertaUpdate.setNegativeButton("Não",new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dia, int which) {

                            }
                        });
                    final AlertDialog dialog = AlertaUpdate.create();
                    //.setTitle("Title")
                    //.setMessage("Message")

                    //AlertDialog dialog = AlertaUpdate2.create();
                   // dialog.getWindow().setBackgroundDrawable(new ColorDrawable(-1));
                    dialog.getWindow().setType(getLayoutType());
                    dialog.show();
                }
            });
        L1.setVisibility(View.GONE);
        //    L1.setGravity(17);
        L1.setOrientation(LinearLayout.VERTICAL);
        L1.setPadding(0, 0, 0, 0);
       L1.setLayoutParams(new LinearLayout.LayoutParams(dp(350), dp(350)));
       // L1.setLayoutParams(new LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
        DL1.setColor(Color.parseColor("BLACK"));
        DL1.setAlpha(1000);
        DL1.setCornerRadius(dp(5));
        DL1.setStroke(1, Color.parseColor("WHITE"));
        L1.setBackground(DL1);
        T1.setText("title");
        T1.setTextColor(Color.parseColor("WHITE"));
        T1.setTextSize(15);
        T1.setGravity(Gravity.CENTER);
        //T1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font2_bold.ttf"),1);
        T1.setPadding(0, 5, 0, 5);
        S1.setLayoutParams(new LinearLayout.LayoutParams(MATCH_PARENT,820));       
        S1.setBackgroundColor(Color.parseColor("#FF696969"));
        R3.setPadding(3, 0, 3, 3);
        R3.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
        R3.setVerticalGravity(10);
      //  STATUS.setText("STATUS: NOT-ACTIVE");
        //STATUS.setTextColor(Color.WHITE);
        //STATUS.setTextSize(15.0f);
        STATUS.setBackgroundResource(R.drawable.close);
        android.widget.LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(120,60);
        STATUS.setLayoutParams(lp);
        STATUS.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font2_bold.ttf"),1);
        RelativeLayout.LayoutParams CloseParams = new RelativeLayout.LayoutParams(-10, -10);
        CloseParams.addRule(11);
        CLOSE.setText("CLOSE");
        CLOSE.setTextSize(15.0f);
        CLOSE.setLayoutParams(new WindowManager.LayoutParams(dp(15), -2));
        CLOSE.setTextColor(Color.WHITE);
        L1.setBackgroundColor(Color.parseColor("#FF696969"));
        //  CLOSE.setBackgroundColor(Color.parseColor("#FF00BAFF"));
      //  CLOSE.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font2_bold.ttf"),1);
       // STATUS.setLayoutParams(CloseParams);
        android.graphics.drawable.GradientDrawable c = new android.graphics.drawable.GradientDrawable();
        c.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        c.setCornerRadii(new float[] {0,0,0,0, 00,00, 90,90});
        c.setColor(Color.parseColor("BLACK"));
        c.setStroke(3,Color.WHITE);
        CLOSE.setBackground(c);
        STATUS.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) {
                    R2.setVisibility(View.VISIBLE);
                    L1.setVisibility(View.GONE);
                }
            });
        option.setVisibility(View.VISIBLE);
        //  option.setGravity(17);
        option.setOrientation(LinearLayout.HORIZONTAL);
        option.setPadding(0, 0, 0, 0);
        option.setLayoutParams(new WindowManager.LayoutParams(MATCH_PARENT, dp(305)));
        option.setBackgroundColor(Color.parseColor("#FF696969"));
       heading = new LinearLayout(context);
       String U = "";
        String P = ""; 
        String E = "";
        String C = "";
        String V = "";
        madherchod = madherchod2.split("!");
        for (int i = 0; i< madherchod.length; i++) {
            final int feature = i + 1;
            String str = madherchod[i];
            if(str.contains("USER_")){
                U = str.replace("USER_","");
            }
            if(str.contains("PASSWORD_")){
                P = str.replace("PASSWORD_","");
            }
            if(str.contains("EXPIRE_")){
                E = str.replace("EXPIRE_","");
            }
            if(str.contains("CREATE_")){
                C = str.replace("CREATE_","");
            }
            if(str.contains("SELLER_")){
                V = str.replace("SELLER_","");
            }
          }
        heading.setBackgroundColor(Color.parseColor("#FF696969"));
        final TextView Crd = new TextView(context);
        Crd.setTextColor(Color.YELLOW);
        Crd.setText("Criado Redesign by @princeinjector");
        Crd.setTypeface(null,Typeface.BOLD);
        Crd.setTextSize(18);
        heading.addView(Crd);
        final TextView Urd = new TextView(context);
        Urd.setTextColor(Color.YELLOW);
        Urd.setText("Usario : "+ U);
        Urd.setTypeface(null,Typeface.BOLD);
        Urd.setTextSize(19);
        heading.addView(Urd);
        heading.setOrientation(LinearLayout.VERTICAL);
        final TextView Cre = new TextView(context);
        Cre.setTextColor(Color.YELLOW);
        Cre.setText("Data de compra : "+ C);
        Cre.setTypeface(null,Typeface.BOLD);
        Cre.setTextSize(19);
        heading.addView(Cre);
        heading.setOrientation(LinearLayout.VERTICAL);
        final TextView Exp = new TextView(context);
        Exp.setTextColor(Color.YELLOW);
        Exp.setText("Vencimento : "+ E);
        Exp.setTypeface(null,Typeface.BOLD);
        Exp.setTextSize(19);
        heading.addView(Exp);
        heading.setOrientation(LinearLayout.VERTICAL);
        final TextView Ven = new TextView(context);
        Ven.setTextColor(Color.YELLOW);
        Ven.setText("Vendedor : "+ V);
        Ven.setTypeface(null,Typeface.BOLD);
        Ven.setTextSize(19);
        heading.addView(Ven);
        heading.setOrientation(LinearLayout.VERTICAL);
        S.setTextColor(Color.YELLOW);
        S.setText(Html.fromHtml("Status : <font Color='red'>offline</font>"));
        S.setTypeface(null,Typeface.BOLD);
        S.setTextSize(19);
        heading.addView(S);
        heading.setOrientation(LinearLayout.VERTICAL);
        ABI.setTextColor(Color.YELLOW);
        if(Build.SUPPORTED_64_BIT_ABIS.length>0){
        ABI.setText(Html.fromHtml("ABI:<font Color='green'>arm64-v8a</font>"));
        } else {
        ABI.setText(Html.fromHtml("ABI:<font Color='green'>armeabi-v7a</font>"));   
        }
        ABI.setTypeface(null,Typeface.BOLD);
        ABI.setTextSize(19);
        heading.addView(ABI);
        heading.setOrientation(LinearLayout.VERTICAL);
        String mm = android.os.Build.MODEL;
        Mod.setTextColor(Color.YELLOW);
        Mod.setText(Html.fromHtml("MODEL:<font Color='green'>"+mm+"</font>"));
        Mod.setTypeface(null,Typeface.BOLD);
        Mod.setTextSize(19);
        heading.addView(Mod);
        Select = new Spinner(context);
        Pass.add("Inject :NOT-SELECTED");
        Pass.add("Inject :VIRTUAL(LOW CHANCE OF SUCCESS)");
        Pass.add("Inject :ALL");
        Select.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, Pass));
        ((ArrayAdapter)Select.getAdapter()).notifyDataSetChanged();
      
        Select.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
                    final int _position = _param3;
                    if(_position==1){
                        injectType = "VIRTUAL";
                        if(InjectVirtual("libserver2.so")){
                            Init();
                                if(IsConnected()){
                            S.setText(Html.fromHtml("Status : <font Color='green'>online</font>"));
                            Select.setEnabled(false);
                                    if(InjectVirtual("libJL.MODZ.so")){
                                Toast.makeText(context, "BYPASS ACTIVE", Toast.LENGTH_LONG).show();
                                
                            }
                            } else {
                          S.setText(Html.fromHtml("Status : <font Color='red'>offline-SOCKET ERROR(YOUR VIRTUAL NOT SUPPORT)</font>"));  
                          }
                        } else {
                      S.setText(Html.fromHtml("Status : <font Color='red'>offline-NO ROOT</font>"));      
                        }
                    }
                    if(_position==2){
                        injectType = "ROOT";
                        if(InjectRoot("libserver2.so")){
                            Init();
                            if(IsConnected()){
                            S.setText(Html.fromHtml("Status : <font Color='green'>online</font>"));    
                            Select.setEnabled(false); 
                                if(InjectVirtual("libJL.MODZ.so")){
                                    Toast.makeText(context, "BYPASS ACTIVE", Toast.LENGTH_LONG).show();
                                }
                            } else{
                            S.setText(Html.fromHtml("Status : <font Color='red'>offline-SOCKET ERROR(YOUR PHONE NOT SUPPORT OR RETRY TO INJECT)</font>"));    
                            }
                        } else {
                            S.setText(Html.fromHtml("Status : <font Color='red'>offline-Magisk Permission denied</font>"));      
                        }
                        
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> _param1) {

                }
            });
          
         heading.addView(Select);
        heading.setOrientation(LinearLayout.VERTICAL);
        S1.addView(heading);
        final TextView T = addText2(context,"SCROOLVIEW HEIGHT 820");
        SeekBar S = new SeekBar(context); 
        S.setMax(1000);
        S.setProgress(820);
        S.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
                    final int _progressValue = _param2;
                    String SSs = "SCROOLVIEW HEIGHT" + " " +_progressValue;
                    T.setText(SSs);
                    int psize = _progressValue;
                    S1.setLayoutParams(new LinearLayout.LayoutParams(MATCH_PARENT,psize)); 
                 //   Size(Send,psize);
                }

                @Override
                public void onStartTrackingTouch(SeekBar _param1) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar _param2) {

                }
            });
        heading.addView(S);
       F();
        /*LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);*/
        int iparams = Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O ? 2038 : 2002;
        FLOATLAYOUT1 = new WindowManager.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, iparams, 8, -3);
        FLOATLAYOUT1.gravity = 51;
        FLOATLAYOUT1.x = 0;
        FLOATLAYOUT1.y = 100;
        Main.addView(R1);
        R1.addView(R2);        
        R1.addView(L1);
        L1.addView(S1);
        R2.addView(DarkIcon);
        R2.addView(cm);
       // L1.addView(option); 
        //option.addView(AddViews);
      //  option.addView(S1);
       // S1.addView(patchesAIM);
       // L1.addView(R3);
        L1.addView(STATUS);
       // R3.addView(STATUS);
         Window = (WindowManager) getSystemService(WINDOW_SERVICE);
        Window.addView(Main, FLOATLAYOUT1);
        Main.setOnTouchListener(new View.OnTouchListener(){
                final View collapsedView = R2;
                final View expandedView = L1;
                private float initialTouchX, initialTouchY;
                private int initialX, initialY;
                @Override
                public boolean onTouch(View view, MotionEvent event) {
                    int action=event.getAction();
                    if (action == MotionEvent.ACTION_DOWN) {
                        initialX = FLOATLAYOUT1.x;
                        initialY = FLOATLAYOUT1.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    } else if (action == MotionEvent.ACTION_UP) {
                        int rawX = (int) (event.getRawX() - initialTouchX);
                        int rawY = (int) (event.getRawY() - initialTouchY);
                        L1.setAlpha(1f);
                        R2.setAlpha(1f);
                        if (rawX < 10 && rawY < 10) {try {
                                collapsedView.setVisibility(View.GONE);
                                expandedView.setVisibility(View.VISIBLE);
                            } catch (NullPointerException e) {

                            }
                        }
                        return true; 
                    } else if (action == MotionEvent.ACTION_MOVE) {
                        FLOATLAYOUT1.x = initialX + ((int) (event.getRawX() - initialTouchX));
                        FLOATLAYOUT1.y = initialY + ((int) (event.getRawY() - initialTouchY));
                        Window.updateViewLayout(Main, FLOATLAYOUT1);
                        return true;
                    }
                    return true;
                }
            });
        DarkIcon.setOnTouchListener(new View.OnTouchListener(){
                final View collapsedView = R2;
                final View expandedView = L1;
                private float initialTouchX, initialTouchY;
                private int initialX, initialY;
                @Override
                public boolean onTouch(View view, MotionEvent event) {
                    int action=event.getAction();
                    if (action == MotionEvent.ACTION_DOWN) {
                        initialX = FLOATLAYOUT1.x;
                        initialY = FLOATLAYOUT1.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    } else if (action == MotionEvent.ACTION_UP) {
                        int rawX = (int) (event.getRawX() - initialTouchX);
                        int rawY = (int) (event.getRawY() - initialTouchY);
                        L1.setAlpha(1f);
                        R2.setAlpha(1f);
                        if (rawX < 10 && rawY < 10) {try {
                                collapsedView.setVisibility(View.GONE);
                                expandedView.setVisibility(View.VISIBLE);
                            } catch (NullPointerException e) {

                            }
                        }
                        return true; 
                    } else if (action == MotionEvent.ACTION_MOVE) {
                        FLOATLAYOUT1.x = initialX + ((int) (event.getRawX() - initialTouchX));
                        FLOATLAYOUT1.y = initialY + ((int) (event.getRawY() - initialTouchY));
                        Window.updateViewLayout(Main, FLOATLAYOUT1);
                        return true;
                    }
                    return true;
                }
            });
        
    }
    private void F(){
        madherchod3 = madherchod4.split(",");
        for (int i = 0; i< madherchod3.length; i++) {
            final int feature = i + 1;
            String str = madherchod3[i];
            if(str.contains("SWITCH_")){
                String Main = str.replace("SWITCH_","");
                String[] sp = null;
                sp = Main.split("_");
                addSwitch(getApplicationContext(),sp[0],Integer.parseInt(sp[1]));
            }
            if(str.contains("TEXT_")){
                String Main = str.replace("TEXT_","");
                String[] sp = null;
                sp = Main.split("_");
                addText(getApplicationContext(),sp[0]);
            }
            if(str.contains("SEEKBAR_")){
                String Main = str.replace("SEEKBAR_","");
                String[] sp = null;
                sp = Main.split("_");
                //Toast.makeText(this, sp[2], Toast.LENGTH_LONG).show();
                SeekBar(getApplicationContext(),sp[0],Integer.parseInt(sp[1]),Integer.parseInt(sp[2]));
            }
      }
    }
    private void addSwitch(final Context context,final String Text,final int Response){
        Switch S = new Switch(context);
        S.setTextColor(Color.BLACK);
        S.setText(Text);
        S.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font2_bold.ttf"),1);
        S.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
                    final boolean _isChecked = _param2;
                    Switch(Response,_isChecked);
                }
            });
        heading.addView(S);
    }
    private void addText(final Context context,final String Text){
        TextView T = new TextView(context);
        T.setTextColor(Color.RED);
        T.setTextSize(20);
        T.setText(Text);
        T.setGravity(40);
        heading.addView(T);
    }
    private void SeekBar(final Context context,final String Text,final int max,final int Send){
        final TextView T = addText2(context,Text + " 0");
        SeekBar S = new SeekBar(context); 
        S.setMax(max);
        S.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
                    final int _progressValue = _param2;
                    String SSs = Text + " " +_progressValue;
                    T.setText(SSs);
                    int psize = _progressValue;
                    Size(Send,psize);
                }

                @Override
                public void onStartTrackingTouch(SeekBar _param1) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar _param2) {

                }
            });
            heading.addView(S);

    }
    private TextView addText2(Context co,String text) {
        TextView CustomText = new TextView(co);
        CustomText.setText(text);
        CustomText.setTextSize(12);
        CustomText.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font2_bold.ttf"),1); 
        CustomText.setPadding(15, 0, 0, 0);
        CustomText.setTextColor(Color.parseColor("YELLOW"));
        //CustomText.setLayoutParams(setParams());
        heading.addView(CustomText);
        return CustomText;
    }
    private boolean InjectRoot(String Lib) {
        try {
            String target = "com.dts.freefireth";
            String injector = this.getApplicationInfo().nativeLibraryDir + File.separator + "libcatchmeifyoucan.so";
            String payload_source = this.getApplicationInfo().nativeLibraryDir + File.separator + Lib;
            String payload_dest = "/data/local/tmp/"+Lib;
            String context = "u:object_r:system_lib_file:s0";
            List<String> STDOUT = new ArrayList<>();
            Shell.su("ls -lZ /system/lib/libandroid_runtime.so").to(STDOUT).exec();
            for (String line : STDOUT) {
                if (line.contains(" u:object_r:") && line.contains(":s0 ")) {
                    context = line.substring(line.indexOf("u:object_r:"));
                    context = context.substring(0, context.indexOf(' '));
                }
            }
            Shell.su("cp " + payload_source + " " + payload_dest).exec();
            Shell.su("chmod 777 " + payload_dest).exec();
            Shell.su("chcon " + context + " " + payload_dest).exec();
            while (Utils.getProcessID(target) <= 0) {}
            Thread.sleep(1000);
            int pid = Utils.getProcessID(target);
            String command = String.format(Locale.ENGLISH,"%s %d %s", injector, pid, payload_dest);
            Shell.su(command).exec();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
	}
    private boolean InjectVirtual(String Lib) {
        try {
            String target = "com.dts.freefireth";
            String injector = this.getApplicationInfo().nativeLibraryDir + File.separator + "libinject.so";
            String payload_source = this.getApplicationInfo().nativeLibraryDir + File.separator + Lib;
            String payload_dest = "/data/local/tmp/"+Lib;
            String context = "u:object_r:system_lib_file:s0";
            List<String> STDOUT = new ArrayList<>();
            Shell.su("ls -lZ /system/lib/libandroid_runtime.so").to(STDOUT).exec();
            for (String line : STDOUT) {
                if (line.contains(" u:object_r:") && line.contains(":s0 ")) {
                    context = line.substring(line.indexOf("u:object_r:"));
                    context = context.substring(0, context.indexOf(' '));
                }
            }
            Shell.su("cp " + payload_source + " " + payload_dest).exec();
            Shell.su("chmod 777 " + payload_dest).exec();
            Shell.su("chcon " + context + " " + payload_dest).exec();
            while (Utils.getProcessID(target) <= 0) {}
            Thread.sleep(1000);
            int pid = Utils.getProcessID(target);
            String command = String.format(Locale.ENGLISH,"%s %d %s", injector, pid, payload_dest);
            Shell.su(command).exec();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        
	}
    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }
    @Override
    public IBinder onBind(Intent p1) {
        return null;
	}
    @Override
    public int onStartCommand(Intent p1, int flags, int startId) {
        //FindLocation(getApplicationContext(),getApplicationContext);
       /* int f = 0;
        load = p1.getStringExtra("Menu");
        byte[] decode = Base64.decode(load, 0);
        byte[] decode1 = Base64.decode(decode, 0);
        byte[] decode2 = Base64.decode(decode1, 0);
        byte[] decode3 = Base64.decode(decode2, 0);
        M = new String(decode3);
        // load = Base64.decode(load.getBytes(),f);
        byte[] decode7 = Base64.decode(p1.getStringExtra("Paid"), 0);
        byte[] decode8 = Base64.decode(decode7, 0);
        byte[] decode9 = Base64.decode(decode8, 0);
        byte[] decode10 = Base64.decode(decode9, 0);
        if (new String (decode10).equals("false")) {
            AT(true);
        } else {
            V = true;
        }
        //AddTextC(1,"false","0");
        byte[] decode4 = Base64.decode(p1.getStringExtra("Title"), 0);    
        byte[] decode5 = Base64.decode(decode4, 0);
        byte[] decode6 = Base64.decode(decode5, 0);
        //byte[] decode7 = Base64.decode(decode2, 0);
        AddTextC(0,new String (decode6),"0");
        on(new String (decode6));*/
       // getLayoutType();
        if(p1.getStringExtra("CHECKSUM1").equals("FUCK")){
            if(p1.getStringExtra("CHECKSUM2").equals("FUCK")){
                if(p1.getStringExtra("CHECKSUM3").equals("FUCK")){
                    f(getApplicationContext());
                }
            }
        }
        
        
        return super.onStartCommand(p1,flags,startId);
        
    }
}
