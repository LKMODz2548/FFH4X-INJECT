#ifndef DARKOFFSETS_H
#define DARKOFFSETS_H
// MADE BY DARKSIDE / BAPAN FF
namespace DarkOffsets {
	enum DarkOffsets {
        GetHeadCollider = 0xB662BC,//1.92
        Cristiano_RayVery = 0x18C78C4,//1.92
     HeadTF = 0x230,  //1.90
     HipTF = 0x234,  //1.90
     ToeTF = 0x244,   //1.90
     HandTF = 0x22c,  //1.90
     DedoTF = 0x234,  //1.90
     LShoulder = 0x268, //1.90
     RShoulder = 0x244, //1.90
    get_IsDieing = 0xB65EA4,  //1.92
     get_Chars = 0x3BCD890, //1.92
     MainCameraTransform = 0x9C, //1.92
     Dictionary = 0x48, //1.92
     IsClientBot = 0x120, //1.92
     get_IsSameTeam = 0xF86B70, //1.92
     get_IsFiring = 0xBC6B38, //1.92
     get_IsSighting = 0xC0FE94, //1.92
     get_isLocalTeam = 0xB74944, //1.92
     get_isVisible = 0xB6B4DC, //1.92//
     get_MaxHP = 0xBAEEE0, //1.92
     get_IsCrouching = 0xB76E98, //1.92
     get_NickName = 0xb6413c, //1.92
     get_isAlive = 0xBD2354, //1.92
     get_MyFollowCamera = 0xB66054, //1.92
     get_PlayerDead = 0xC052B8, //1.92
     get_IsFemale = 0xB67040, //1.92
     set_aim = 0xB67C18, // 1.92 0xbef8cc
     get_imo = 0xB5F2C4, // 1.92
     set_esp = 0x22977B8, //1.92,0x2198aac set_esp
     set_esp2 = 0x20A6BBC, //1.92//
     GetAttackableCenterWS = 0x2177460, //1.92
     AddTeammateHud = 0xD00190, //1.92
     ShowDynamicPopupMessage = 0xCDEF34, //1.92
     ShowPopupMessage = 0xBEF45C, //1.92
     U3DStr = 0x3BDC114, //1.92
     CurrentUIScene = 0xF82B04, //1.92
     U3DStrConcat = 0x3BCD1AC,  //1.92
     get_CurHp = 0xBAEDB8, //1.92
     Component_GetTransform = 0x3CDC440, // 1.92
     Transform_INTERNAL_GetPosition = 0x4283C00, //1.92
     Transform_INTERNAL_SetPosition = 0x4283CA0, //1.92
     Transform_INTERNAL_Get_real_Position = 0xF2DD04,//1.92
     GetForward = 0x4284760, //1.92
     GetLocalPlayer =  0x18aa534, 
     GetLocalPlayer2 = 0x2076628, //1.92,0x1ADAF10,0x1A0FDD8
     get_IsDead = 0x1078E34,//1.92
     Current_Local_Player = 0xF841C0, //1.92
     GetLocalPlayerOrObServer = 0xF84AC0, //1.92
     GetPhysXPose = 0xB76E20,  //1.92
     GetPhysXState = 0xB76CD4, //1.92
     
     Curent_Match = 0xF83DD0, //1.92//0xF2D914
     Camera_main = 0x3CDA25C, //1.92
     WorldToScreenPoint = 0x3CD98E8, //1.92
     LineRenderer_Set_PositionCount = 0x3A842C8, //1.90
     LineRenderer_SetPosition = 0x36244F0, //1.90
     GrenadeLine_DrawLine = 0xFDA3D0, //1.90
     GrenadeLine_Update = 0xFD9BB4, //1.90
     set_startColor = 0x3623970, //1.90
     set_endColor = 0x36243B8, //1.90
     GetLocalCar = 0xB68DE4, //1.90
     //fly
     GetPhysData = 0xB76D54,//1.92
     OnStopCatapultFalling = 0xBE3724,//1.92
     IsCatapultFalling = 0xB6F8E4,//1.92
     FlyUp = 0x28,
     FlySpeed = 0x2C,
     IsDriver = 0xbf077c, 
	};
}
	
#endif

