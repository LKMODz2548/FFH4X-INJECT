#ifndef DARKHOOKS_H
#define DARKHOOKS_H
#include "DarkOffsets.h"
class Vvector3 {
public:
    float X;
    float Y;
    float Z;
    Vvector3() : X(0), Y(0), Z(0) {}
    Vvector3(float x1, float y1, float z1) : X(x1), Y(y1), Z(z1) {}
    Vvector3(const Vvector3 &v);
    ~Vvector3();
};// MADE BY DARKSIDE / BAPAN FF
Vvector3::Vvector3(const Vvector3 &v) : X(v.X), Y(v.Y), Z(v.Z) {}
Vvector3::~Vvector3() {}
static void *GetHeadCollider(void* player){
    void *(*_GetHeadCollider)(void *players) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::GetHeadCollider);
    return _GetHeadCollider(player);
}
static bool Cristiano_RayVery(Vector3 camLocation, Vector3 headLocation, unsigned int LayerID, void* collider) {
    bool (*_Cristiano_RayVery)(Vector3 camLocation, Vector3 headLocation, unsigned int LayerID, void* collider) = (bool(*)(Vector3, Vector3, unsigned int, void*))getAbsoluteAddress(libil2cpp, DarkOffsets::Cristiano_RayVery);
    return _Cristiano_RayVery(camLocation, headLocation, LayerID, collider);
}
static void *GetLocalVehicle(void* local) {
    void *(*_GetLocalVehicle)(void * player) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::GetLocalCar);
    return _GetLocalVehicle(local);
}

static bool get_IsPassenger(void * Pass) {
    bool (*_get_IsPassenger)(void * pass) = (bool (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::IsDriver);
    return _get_IsPassenger(Pass);
}

static void *get_MyPhsXData(void *player) {
    void *(*_get_MyPhsXData)(void *component) = (void *(*)(void *))getAbsoluteAddress(libil2cpp,DarkOffsets::GetPhysData);
    return _get_MyPhsXData(player);
}

static void LineRenderer_SetPosition(void *Render, int value, Vector3 Location){
    void (*_LineRenderer_SetPosition)(void *Render, int value, Vector3 Location) = (void (*)(void*, int, Vector3))getAbsoluteAddress(libil2cpp, DarkOffsets::LineRenderer_SetPosition);
    return _LineRenderer_SetPosition(Render, value, Location);
}

static void LineRenderer_Set_PositionCount(void *Render, int value){
    void (*_LineRenderer_Set_PositionCount)(void *Render, int value) = (void (*)(void*, int))getAbsoluteAddress(libil2cpp, DarkOffsets::LineRenderer_Set_PositionCount);
    return _LineRenderer_Set_PositionCount(Render, value);
}

static void GrenadeLine_DrawLine(void *instance, Vector3 start, Vector3 end, Vector3 position) {
    void (*_GrenadeLine_DrawLine)(void *clz, Vector3 throwPos, Vector3 throwVel, Vector3 gravity) = (void (*)(void*, Vector3, Vector3,Vector3)) getAbsoluteAddress(libil2cpp, DarkOffsets::GrenadeLine_DrawLine);
    return _GrenadeLine_DrawLine(instance, start, end, position);
}

static void *GetLocalPlayer(void* Match) {
    void *(*_GetLocalPlayer)(void *match) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::GetLocalPlayer);
    return _GetLocalPlayer(Match);
}
static void *GetLocalPlayer2(void* Match) {
    void *(*_GetLocalPlayer2)(void *match) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::GetLocalPlayer2);
    return _GetLocalPlayer2(Match);
}

static void *Current_Local_Player() {
    void *(*_Local_Player)(void *players) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::Current_Local_Player);
    return _Local_Player(NULL);
}
static Vector3 GetAttackableCenterWS(void *player) {
    Vector3 (*_GetAttackableCenterWS)(void *players) = (Vector3 (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::GetAttackableCenterWS);
    return _GetAttackableCenterWS(player);
}
static void *GetLocalPlayerOrObServer() {
    void *(*_GetLocalPlayerOrObServer)(void *players) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::GetLocalPlayerOrObServer);
    return _GetLocalPlayerOrObServer(NULL);
}

static void *get_MyFollowCamera(void *players) {
    void *(*_get_MyFollowCamera) (void *player) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_MyFollowCamera);
    return _get_MyFollowCamera(players);
}
//Autokill 


static void PlayerNetwork_StopFire(void *PlayerID, void *RemainingAmmo) {
    void (*_PlayerNetwork_StopFire)(void *PlayerID, void *RemainingAmmo) = (void (*)(void *, void *))getAbsoluteAddress(libil2cpp,0x13149FC);
    _PlayerNetwork_StopFire(PlayerID,RemainingAmmo);
}



static void *Player_GetWeaponOnHand(void *_this) {
    void *(*_Player_GetWeaponOnHand)(void *_this) = (void *(*)(void *))getAbsoluteAddress(libil2cpp,0xB6FA24);
    return _Player_GetWeaponOnHand(_this);
} 
static bool get_isLocalTeam(void *player) {
    bool (*_get_isLocalTeam)(void *players) = (bool (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_isLocalTeam);
    return _get_isLocalTeam(player);
}

static bool get_IsDieing(void *player) {
    bool (*_get_die)(void *players) = (bool (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_IsDieing);
    return _get_die(player);
}
static void set_esp(void *imo, Vector3 x, Vector3 y) {
    void (*_set_esp)(void *imo, Vector3 X, Vector3 Y) = (void (*)(void *, Vector3, Vector3))getAbsoluteAddress(libil2cpp, DarkOffsets::set_esp);
    _set_esp(imo, x, y);
}
static bool get_IsDead(void *player) {
    bool (*_get_IsDead)(void *players) = (bool (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_IsDead);
    return _get_IsDead(player);
}

static bool IsClientBot(void *player) {
    bool (*_IsClientBot)(void *players) = (bool (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::IsClientBot);
    return _IsClientBot(player);
}

static int get_MaxHP(void* enemy) {
    int (*_get_MaxHP)(void* player) = (int(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_MaxHP);
    return _get_MaxHP(enemy);
}

static bool get_IsFiring(void *player) {
    bool (*_get_IsFiring)(void *players) = (bool (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_IsFiring);
    return _get_IsFiring(player);
}

static bool get_IsSighting(void *player) {
    bool (*_get_IsSighting)(void *players) = (bool (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_IsSighting);
    return _get_IsSighting(player);
}

static bool get_isVisible(void *player) {
    bool (*_get_isVisible)(void *players) = (bool (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_isVisible);
    return _get_isVisible(player);
}
static int GetHp(void* player) {
    int (*_GetHp)(void* players) = (int(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_CurHp);
    return _GetHp(player);
}
static Vector3 GetForward(void *player) {
    Vector3 (*_GetForward)(void *players) = (Vector3 (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::GetForward);
    return _GetForward(player);
}

static void set_aim(void *player, Quaternion look) {
    void (*_set_aim)(void *players, Quaternion lock) = (void (*)(void *, Quaternion))getAbsoluteAddress(libil2cpp, DarkOffsets::set_aim);
    _set_aim(player, look);
}

static Vector3 Transform_INTERNAL_GetPosition(void *player) {
    Vector3 out = Vector3::Zero();
    void (*_Transform_INTERNAL_GetPosition)(void *transform, Vector3 * out) = (void (*)(void *, Vector3 *))getAbsoluteAddress(libil2cpp, DarkOffsets::Transform_INTERNAL_GetPosition);
    _Transform_INTERNAL_GetPosition(player, &out);
    return out;
}

static void Transform_INTERNAL_SetPosition(void *player, Vvector3 inn) {
    void (*Transform_INTERNAL_SetPosition)(void *transform, Vvector3 in) = (void (*)(void *, Vvector3))getAbsoluteAddress(libil2cpp, DarkOffsets::Transform_INTERNAL_SetPosition);
    Transform_INTERNAL_SetPosition(player, inn);
}

static void *Transform_INTERNAL_Get_real_Position(void *player) {
    void *(*_Transform_INTERNAL_Get_real_Position)(void *Transform) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::Transform_INTERNAL_Get_real_Position);
    return _Transform_INTERNAL_Get_real_Position(player);
}

static bool get_IsCrouching(void *player) {
    bool (*_get_IsCrouching)(void *players) = (bool (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_IsCrouching);
    return _get_IsCrouching(player);
}

static void *Component_GetTransform(void *player) {
    void *(*_Component_GetTransform)(void *component) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::Component_GetTransform);
    return _Component_GetTransform(player);
}

static void *Camera_main() {
    void *(*_Camera_main)(void *nuls) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::Camera_main);
    return _Camera_main(nullptr);
}

static void *Curent_Match() {
    void *(*_Curent_Match) (void *nuls) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::Curent_Match);
    return _Curent_Match(NULL);
}

static void *GetLocalCar(void *Match) {
    void *(*_GetLocalCar) (void *match) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::GetLocalCar);
    return _GetLocalCar(Match);
}

char get_Chars(monoString *str, int index){
    char (*_get_Chars)(monoString *str, int index) = (char (*)(monoString *, int))getAbsoluteAddress(libil2cpp, DarkOffsets::get_Chars);
    return _get_Chars(str, index);
}

static monoString* get_NickName(void *player) {
    monoString* (*_get_NickName)(void *players) = (monoString * (*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_NickName);
    return _get_NickName(player);
}



static monoString *U3DStr(const char *str) {
    monoString *(*String_CreateString)(void *_this, const char *str) = (monoString * (*)(void *, const char *))getAbsoluteAddress(libil2cpp, DarkOffsets::U3DStr);
    return String_CreateString(NULL, str);
}

static monoString *U3DStrFormat(float distance, float vida) {
    char buffer[128] = {0};
    sprintf(buffer, "DIST %.f M | PLAYER BOT | %.f HP", distance,vida);
    return U3DStr(buffer);
}

static monoString *U3DStrPlayer2(float distance, float vida) {
    char buffer[128] = {0};
    sprintf(buffer, "DIST %.f M | PLAYER REAL | %.f HP", distance,vida);
    return U3DStr(buffer);
}
static void *get_imo(void *player) {
    void *(*_get_imo)(void *players) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::get_imo);
    return _get_imo(player);
}
static void *CurrentUIScene() {
    void *(*_CurrentUIScene)(void *nuls) = (void *(*)(void *))getAbsoluteAddress(libil2cpp, DarkOffsets::CurrentUIScene);
    return _CurrentUIScene(NULL);
}

static void AddTeammateHud(void *player, monoString *nick, monoString *grup) {
    void (*_AddTeammateHud)(void *players, monoString * nicks, monoString * nickss) = (void (*)(void *, monoString *, monoString *))getAbsoluteAddress(libil2cpp, DarkOffsets::AddTeammateHud);
    void *ui = CurrentUIScene();
    if (ui != NULL) {
        _AddTeammateHud(player, nick,grup);
    }
}

static Vector3 WorldToScreenPoint(void *WorldCam, Vector3 WorldPos) {
    Vector3 (*_WorldToScreenScene)(void* Camera, Vector3 position) = (Vector3 (*)(void*, Vector3)) getAbsoluteAddress(libil2cpp, DarkOffsets::WorldToScreenPoint);
    return _WorldToScreenScene(WorldCam,WorldPos);
}

//*****////
static void * getHead(void *player)
{
    void * (*_newHeadMods)(void *_this) = (void*(*)(void*))getAbsoluteAddress(libil2cpp, 0xBC14D0);
    return _newHeadMods(player);
}

static void * HipTF(void *player)
{
    void * (*_newHipMods)(void *_this) = (void*(*)(void*))getAbsoluteAddress(libil2cpp, 0xBC169C);
    return _newHipMods(player);
}

static void * ToeTF(void *player)
{
    void * (*_newToeMods)(void *_this) = (void*(*)(void*))getAbsoluteAddress(libil2cpp, 0xBC1EA8);
    return _newToeMods(player);
}
 

//****////


Vector3 GetHeadPosition(void* player) {
    return Transform_INTERNAL_GetPosition(Component_GetTransform(getHead(player)));
}

Vector3 GetHipPosition(void* player) {
    return Transform_INTERNAL_GetPosition(Component_GetTransform(HipTF(player)));
}

Vector3 GetToePosition(void* player) {
    return Transform_INTERNAL_GetPosition(Component_GetTransform(ToeTF(player)));
}
/****////




Vector3 GetRShoulderPosition(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + DarkOffsets::RShoulder));
}

Vector3 GetLShoulderPosition(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + DarkOffsets::LShoulder));
}

Vector3 CameraMain(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + DarkOffsets::MainCameraTransform));
}
Vector3 GetPlayerNamePosition(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + DarkOffsets::LShoulder));
}

static char* LifePlayer(int HP){
 if(HP == 0) {
     return "HP: 0";
 } else if(HP == 1) {
  return "HP: 1";
 } else if(HP == 2) {
  return "HP: 2";
 } else if(HP == 3) {
  return "HP: 3";
 } else if(HP == 4) {
  return "HP: 4";
 } else if(HP == 5) {
  return "HP: 5";
 } else if(HP == 6) {
  return "HP: 6";
 } else if(HP == 7) {
  return "HP: 7";
 } else if(HP == 8) {
  return "HP: 8";
 } else if(HP == 9) {
  return "HP: 9";
 } else if(HP == 10) {
  return "HP: 10";
 } else if(HP == 11) {
  return "HP: 11";
 } else if(HP == 12) {
  return "HP: 12";
 } else if(HP == 13) {
  return "HP: 13";
 } else if(HP == 14) {
  return "HP: 15";
 } else if(HP == 15) {
  return "HP: 15";
 } else if(HP == 16) {
  return "HP: 16";
 } else if(HP == 17) {
  return "HP: 17";
 } else if(HP == 18) {
  return "HP: 18";
 } else if(HP == 19) {
  return "HP: 19";
 } else if(HP == 20) {
  return "HP: 20";
 } else if(HP == 21) {
  return "HP: 21";
 } else if(HP == 22) {
  return "HP: 22";
 } else if(HP == 23) {
  return "HP: 23";
 } else if(HP == 24) {
  return "HP: 24";
 } else if(HP == 25) {
  return "HP: 25";
 } else if(HP == 26) {
  return "HP: 26";
 } else if(HP == 27) {
  return "HP: 27";
 } else if(HP == 28) {
  return "HP: 28";
 } else if(HP == 29) {
  return "HP: 29";
 } else if(HP == 30) {
  return "HP: 30";
 } else if(HP == 31) {
  return "HP: 31";
 } else if(HP == 32) {
  return "HP: 32";
 } else if(HP == 33) {
  return "HP: 33";
 } else if(HP == 34) {
  return "HP: 34";
 } else if(HP == 35) {
  return "HP: 35";
 } else if(HP == 36) {
  return "HP: 36";
 } else if(HP == 37) {
  return "HP: 37";
 } else if(HP == 38) {
  return "HP: 38";
 } else if(HP == 39) {
  return "HP: 39";
 } else if(HP == 40) {
  return "HP: 40";
 } else if(HP == 41) {
  return "HP: 41";
 } else if(HP == 42) {
  return "HP: 42";
 } else if(HP == 43) {
  return "HP: 43";
 } else if(HP == 44) {
  return "HP: 44";
 } else if(HP == 45) {
  return "HP: 45";
 } else if(HP == 46) {
  return "HP: 46";
 } else if(HP == 47) {
  return "HP: 47";
 } else if(HP == 48) {
  return "HP: 48";
 } else if(HP == 49) {
  return "HP: 49";
 } else if(HP == 50) {
  return "HP: 50";
 } else if(HP == 51) {
  return "HP: 51";
 } else if(HP == 52) {
  return "HP: 52";
 } else if(HP == 53) {
  return "HP: 53";
 } else if(HP == 54) {
  return "HP: 54";
 } else if(HP == 55) {
  return "HP: 55";
 } else if(HP == 56) {
  return "HP: 56";
 } else if(HP == 57) {
  return "HP: 57";
 } else if(HP == 58) {
  return "HP: 58";
 } else if(HP == 59) {
  return "HP: 59";
 } else if(HP == 60) {
  return "HP: 60";
 } else if(HP == 61) {
  return "HP: 61";
 } else if(HP == 62) {
  return "HP: 62";
 } else if(HP == 63) {
  return "HP: 63";
 } else if(HP == 64) {
  return "HP: 64";
 } else if(HP == 65) {
  return "HP: 65";
 } else if(HP == 66) {
  return "HP: 66";
 } else if(HP == 67) {
  return "HP: 67";
 } else if(HP == 68) {
  return "HP: 68";
 } else if(HP == 69) {
  return "HP: 69";
 } else if(HP == 70) {
  return "HP: 70";
 } else if(HP == 71) {
  return "HP: 71";
 } else if(HP == 72) {
  return "HP: 72";
 } else if(HP == 73) {
  return "HP: 73";
 } else if(HP == 74) {
  return "HP: 74";
 } else if(HP == 75) {
  return "HP: 75";
 } else if(HP == 76) {
  return "HP: 76";
 } else if(HP == 77) {
  return "HP: 77";
 } else if(HP == 78) {
  return "HP: 78";
 } else if(HP == 79) {
  return "HP: 79";
 } else if(HP == 80) {
  return "HP: 80";
 } else if(HP == 81) {
  return "HP: 81";
 } else if(HP == 82) {
  return "HP: 82";
 } else if(HP == 83) {
  return "HP: 83";
 } else if(HP == 84) {
  return "HP: 84";
 } else if(HP == 85) {
  return "HP: 85";
 } else if(HP == 86) {
  return "HP: 86";
 } else if(HP == 87) {
  return "HP: 87";
 } else if(HP == 88) {
  return "HP: 88";
 } else if(HP == 89) {
  return "HP: 89";
 } else if(HP == 90) {
  return "HP: 90";
 } else if(HP == 91) {
  return "HP: 91";
 } else if(HP == 92) {
  return "HP: 92";
 } else if(HP == 93) {
  return "HP: 93";
 } else if(HP == 94) {
  return "HP: 94";
 } else if(HP == 95) {
  return "HP: 95";
 } else if(HP == 96) {
  return "HP: 96";
 } else if(HP == 97) {
  return "HP: 97";
 } else if(HP == 98) {
  return "HP: 98";
 } else if(HP == 99) {
  return "HP: 99";
 } else if(HP == 100) {
  return "HP: 100";
 } else if(HP == 102) {
  return "HP: 102";
 } else if(HP == 103) {
  return "HP: 103";
 } else if(HP == 104) {
  return "HP: 104";
 } else if(HP == 105) {
  return "HP: 105";
 } else if(HP == 106) {
  return "HP: 106";
 } else if(HP == 107) {
  return "HP: 107";
 } else if(HP == 108) {
  return "HP: 108";
 } else if(HP == 109) {
  return "HP: 109";
 } else if(HP == 110) {
  return "HP: 110";
 } else if(HP == 111) {
  return "HP: 111";
 } else if(HP == 112) {
  return "HP: 112";
 } else if(HP == 113) {
  return "HP: 113";
 } else if(HP == 114) {
  return "HP: 115";
 } else if(HP == 115) {
  return "HP: 115";
 } else if(HP == 116) {
  return "HP: 116";
 } else if(HP == 117) {
  return "HP: 117";
 } else if(HP == 118) {
  return "HP: 118";
 } else if(HP == 119) {
  return "HP: 119";
 } else if(HP == 120) {
  return "HP: 120";
 } else if(HP == 121) {
  return "HP: 121";
 } else if(HP == 122) {
  return "HP: 122";
 } else if(HP == 123) {
  return "HP: 123";
 } else if(HP == 124) {
  return "HP: 124";
 } else if(HP == 125) {
  return "HP: 125";
 } else if(HP == 126) {
  return "HP: 126";
 } else if(HP == 127) {
  return "HP: 127";
 } else if(HP == 128) {
  return "HP: 128";
 } else if(HP == 129) {
  return "HP: 129";
 } else if(HP == 130) {
  return "HP: 130";
 } else if(HP == 131) {
  return "HP: 131";
 } else if(HP == 132) {
  return "HP: 132";
 } else if(HP == 133) {
  return "HP: 133";
 } else if(HP == 134) {
  return "HP: 134";
 } else if(HP == 135) {
  return "HP: 135";
 } else if(HP == 136) {
  return "HP: 136";
 } else if(HP == 137) {
  return "HP: 137";
 } else if(HP == 138) {
  return "HP: 138";
 } else if(HP == 139) {
  return "HP: 139";
 } else if(HP == 140) {
  return "HP: 140";
 } else if(HP == 141) {
  return "HP: 141";
 } else if(HP == 142) {
  return "HP: 142";
 } else if(HP == 143) {
  return "HP: 143";
 } else if(HP == 144) {
  return "HP: 144";
 } else if(HP == 145) {
  return "HP: 145";
 } else if(HP == 146) {
  return "HP: 146";
 } else if(HP == 147) {
  return "HP: 147";
 } else if(HP == 148) {
  return "HP: 148";
 } else if(HP == 149) {
  return "HP: 149";
 } else if(HP == 150) {
  return "HP: 150";
 } else if(HP == 151) {
  return "HP: 151";
 } else if(HP == 152) {
  return "HP: 152";
 } else if(HP == 153) {
  return "HP: 153";
 } else if(HP == 154) {
  return "HP: 154";
 } else if(HP == 155) {
  return "HP: 155";
 } else if(HP == 156) {
  return "HP: 156";
 } else if(HP == 157) {
  return "HP: 257";
 } else if(HP == 158) {
  return "HP: 158";
 } else if(HP == 159) {
  return "HP: 159";
 } else if(HP == 160) {
  return "HP: 160";
 } else if(HP == 161) {
  return "HP: 161";
 } else if(HP == 162) {
  return "HP: 162";
 } else if(HP == 163) {
  return "HP: 163";
 } else if(HP == 164) {
  return "HP: 164";
 } else if(HP == 165) {
  return "HP: 165";
 } else if(HP == 166) {
  return "HP: 166";
 } else if(HP == 167) {
  return "HP: 167";
 } else if(HP == 168) {
  return "HP: 168";
 } else if(HP == 169) {
  return "HP: 169";
 } else if(HP == 170) {
  return "HP: 170";
 } else if(HP == 171) {
  return "HP: 171";
 } else if(HP == 172) {
  return "HP: 172";
 } else if(HP == 173) {
  return "HP: 173";
 } else if(HP == 174) {
  return "HP: 174";
 } else if(HP == 175) {
  return "HP: 175";
 } else if(HP == 176) {
  return "HP: 176";
 } else if(HP == 177) {
  return "HP: 177";
 } else if(HP == 178) {
  return "HP: 178";
 } else if(HP == 179) {
  return "HP: 179";
 } else if(HP == 180) {
  return "HP: 180";
 } else if(HP == 181) {
  return "HP: 181";
 } else if(HP == 182) {
  return "HP: 182";
 } else if(HP == 183) {
  return "HP: 183";
 } else if(HP == 184) {
  return "HP: 184";
 } else if(HP == 185) {
  return "HP: 185";
 } else if(HP == 186) {
  return "HP: 186";
 } else if(HP == 187) {
  return "HP: 187";
 } else if(HP == 188) {
  return "HP: 188";
 } else if(HP == 189) {
  return "HP: 189";
 } else if(HP == 190) {
  return "HP: 190";
 } else if(HP == 191) {
  return "HP: 191";
 } else if(HP == 192) {
  return "HP: 192";
 } else if(HP == 193) {
  return "HP: 193";
 } else if(HP == 194) {
  return "HP: 194";
 } else if(HP == 195) {
  return "HP: 195";
 } else if(HP == 196) {
  return "HP: 196";
 } else if(HP == 197) {
  return "HP: 197";
 } else if(HP == 198) {
  return "HP: 198";
 } else if(HP == 199) {
  return "HP: 199";
 } else if(HP == 200) {
  return "HP: 200";
    }
 }
 
#endif





