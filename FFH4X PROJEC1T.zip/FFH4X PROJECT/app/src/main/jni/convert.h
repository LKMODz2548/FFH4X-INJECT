// @princeinjector
//MADHERCHOD CREDIT REMOVE KIYA TOH TERA PURA NEXT GENERATION WILL BE GAY
string int_to_string(int num)
{
     string str = to_string(num);
     return str;
}
int string_to_int(string str) 
{ 
    int value;
    value = std::stoi(str);
    return value;
}
string float_to_string (float value) 
{
    string str; 
    str = to_string(value);
    return str;
}
float string_to_float (string str) 
{
    float value; 
    value = std::stoi(str);
    return value;
}
char string_to_char(string str) 
{
    string convert = str;
    int get_len = convert.length();
    char char_array[get_len + 1];
    strcpy(char_array, convert.c_str());
    for (int i = 0; i < get_len; i++)
    return char_array[i];
}
string char_to_string (char value) 
{
    constexpr int CHAR_LENGTH = 1;
    string tmp_string(CHAR_LENGTH, value);
    return tmp_string;
}

//READ FILE FROM PATH YOU NEED TO ADD STORAGE PERMISSION IN manifest.xml
string read_file(string file_path)
{
  string line;
  string output = "";
  ifstream myfile2 (file_path);
  if (myfile2.is_open())
  {
    while ( getline (myfile2,line) )
    {
      output = '\n' + line + '\n';
      return output;
    }
    myfile2.close();
    return "";
  }
  else cout << "Unable to open file";
  return "";
}
void write_file (string path,string str) 
{
  ofstream myfile;
  myfile.open (path);
  myfile << str;
  myfile.close();
}
void delet_file (string path) 
{
    char fileName = string_to_char(path);
    //int delet = remove(fileName);
     //CURRENTLY IT WAS SHOWING SOME ERROR SO I REMOVE
}
bool file_exist(string path) 
{
    ifstream myfile;
    myfile.open(path);
    if(myfile) {
        return true;
    }else{
        return false;
    }
}
uintptr_t string_to_offset(string offset) 
{
   char value = string_to_char(offset);
   uintptr_t MainVa = value;
   return MainVa;
} 
const void * string_to_void(string str)
{
    const void * a = str.c_str();
    return a;
}
string jstring_to_string (JNIEnv *env, jstring jStr)
{
    const char *cstr = env->GetStringUTFChars(jStr, NULL);
    std::string str = std::string(cstr);
    return str;
}
Vector2 Vector3_to_Vector2(Vector3 v3)
{
    int Fix = 0;
    Vector2 v2 = Vector2(v3.X, v3.Y);
    return v2;
}
Vector3 Vector2_to_Vector3(Vector2 v2)
{
    Vector3 v3 = Vector3(v2.X,v2.Y);
    return v3;
}
