#include <jni.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include "images.h"
#include <SOCKET/client.h>
//#include "DarkHooks.h"
#include "Unity/Unity.h"
#include "DarkSideEsp/ESP.h"
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "convert.h"

bool EnableFly = false;
bool EnableFov = false;
bool AimAuto = false;
bool EnableAim = false; 
bool AimFire = false;
bool AimScope = false;
bool AimVisible = false;
bool AimCrouch = false;
bool AimKill = false;

bool EspGranade = false;
bool EspFire = false;
bool EspAlert = false;
bool EspLine = false;
bool EspBox = false;
bool EspDistance = false;
bool EspName = false;
bool EspHealth = false;
bool SkillCar = false;
bool IsSpeed = false;

bool MedkitRun = false;
bool Speed100xB = false;
bool UnderCarB = false;
bool DoubleGunB = false;
bool StoneB = false;
bool cameraview = false;
bool cameraview1 = false; 
bool cameraview2 = false;
bool cameraview3 = false;
bool cameraview4 = false;
bool cameraview5 = false;
bool cameraview6 = false;
bool Black = false;
bool Ghost = false; 
bool WallHack = false;
bool TP = false;
bool TPCAR = false;
bool TPF = false;
bool TPS = false;
bool Increase = false;
bool TPC = false;
bool sendoffset = false;
bool badge = false;
bool flycheck = false;
bool f1 = false;
bool f2 = false;
bool f3 = false;
bool f4 = false;
bool f5 = false;
bool f6 = false;
float PlYerSpeed = 0.0f;
Color maincolor = Color::Black();
int flyaltura = 0;
float flyspeed = 0;
int FlyCatapultX = 0;
int FlyPosX = 0;
int FlySpeedX = 0;
float fly = 0;
string offset = "FUCK99";
float espSize = 15.0f;
float espPosition = 0.9f;
float espLinePosition = 0.0f;
bool ResetGuest = false;
float EspFixed = 8.0f;
float Fov_Aim = 0.0f;
float tpRange = 0.0f;
SocketClient client;
void startDaemon();
int startClient();
bool isConnected();
void stopClient();
bool initServer();
bool stopServer();
string MainText = OBFUSCATE("Prince Injector");
enum Mode {
    InitMode = 1,
    HackMode = 2,
    StopMode = 3,
    EspMode = 99,
};
struct VIP {
    string time = "";
}prince;
enum m_Features {
    g_EnableAim = 3,
    g_AimFire = 4,
    g_AimScope = 5,
    g_AimVisible = 6,
    g_AimKill = 7,
    g_AimFov = 111,
    g_EspGranade = 8,
	g_EspFire = 119,
    g_EspAlert = 9,
    g_EspLine = 10,
    g_EspBox = 11,
    g_EspName = 12,
    g_EspDistance = 13,
    g_EspHealth = 14,
    g_CarHeight = 112,
    g_CarPos = 113,
    g_CarSpeed = 114,
    g_SkillCar = 15,
    g_FlyHeight = 115,
    g_FlySpeed = 116,
    g_MedkitRun = 16,
    g_IsSpeed = 17,
    g_Speed100x = 18,
    g_UnderCar = 19,
    g_DoubleGun = 20,
    g_Stone = 21,
    g_ResetGuest = 22,
	g_cameraview = 23,
	g_cameraview1 = 24,
	g_cameraview2 = 25,
	g_cameraview3 = 26,
	g_cameraview4 = 27,
	g_cameraview5 = 28,
	g_cameraview6 = 29,
	g_Ghost = 30,
	g_WallHack = 31,
	g_TP = 32,
	g_TPCAR = 33,
	g_TPF = 34,
	g_TPS = 35,
	g_TPC = 36,
	g_sendoffset = 37,
    g_badge = 38,
    g_fly = 39,
    g_flyspeed = 40,
    g_op = 41,
    g_f1 = 42,
    g_f2 = 43,
    g_f3 = 44,
    g_f4 = 45,
    g_f5 = 46,
    g_f6 = 47,
    g_ExtraSeek = 48,
    g_tpRange = 49,
    g_AimAuto = 50,
    g_enableFov = 51,
    g_AimCrouch = 52,
    g_OnFly = 53,
    g_Black = 54,
    g_PlYerSpeed = 55,
    g_Recoil = 56,
};

struct Request {
    int Mode;
    bool m_IsOn;
    int value;
    int screenWidth;
    int screenHeight;
};

#define maxplayerCount 54

struct PlayerData {
    char PlayerName[64];
    float Health;
    float Distance2;
    bool get_IsDieing;
    bool isBot;
    Vector3 CloseEnemyHeadLocation;
    Vector3 HeadLocation;
    Vector3 ToeLocation;
    Vector2 RShoulder;
    Vector3 LShoulder;
    Vector3 Toe;
    Vector3 Hip;
    Vector3 Head;
    int x;
    int y;
    int z;
    int id;
    int h;
    char debug[60];
};

struct Response {
    bool Success;
    int PlayerCount;
    PlayerData Players[maxplayerCount];
};


int startClient(){
    client = SocketClient();
    if(!client.Create()){ return -1; }
    if(!client.Connect()){ return -1; }
    if(!initServer()){ return -1; }
    return 0;
}

bool isConnected(){
    return client.connected;
}

void stopClient() {
    if(client.created && isConnected()){
        stopServer();
        client.Close();
    }
}

bool initServer() {
    Request request{Mode::InitMode, true, 0};
    int code = client.sendX((void*) &request, sizeof(request));
    if(code > 0) {
        Response response{};
        size_t length = client.receive((void*) &response);
        if(length > 0) {
            return response.Success;
        }
    }
    return false;
}

bool stopServer() {
    Request request{Mode::StopMode};
    int code = client.sendX((void*) &request, sizeof(request));
    if(code > 0) {
        Response response{};
        size_t length = client.receive((void*) &response);
        if(length > 0) {
            return response.Success;
        }
    }
    return false;
}

void SendFeatuerevalue(int number, bool ftr, int value) {
    Request request{number, ftr, value};
    int code = client.sendX((void*) &request, sizeof(request));
    if (code > 0) {
        Response response{};
        size_t length = client.receive((void*) &response);
        if (length > 0) {
            ;
        }
    }
}

void SendFeatuere(int32_t number, bool ftr) {
    Request request{number, ftr};
    int code = client.sendX((void*) &request, sizeof(request));
    if (code > 0) {
        Response response{};
        size_t length = client.receive((void*) &response);
        if (length > 0) {
             ;
        }
    }
}

Response getData(int screenWidth, int screenHeight){
    Request request{Mode::EspMode, screenWidth, screenHeight};
    int code = client.sendX((void*) &request, sizeof(request));
    if(code > 0){
        Response response{};
        size_t length = client.receive((void*) &response);
        if(length > 0){
            return response;
        }
    }
    Response response{false, 0};
    return response;
}
bool Esp_ = false;
void Switch(
JNIEnv *env, jclass type, jint num, jboolean boolean) {
    switch (num){
        
        
        case 0: EnableAim = boolean; SendFeatuere(m_Features::g_EnableAim, EnableAim);break;
        case 1:AimAuto = boolean;SendFeatuere(m_Features::g_AimAuto, AimAuto);  break;
        case 2:EnableFov = boolean;SendFeatuere(m_Features::g_enableFov, EnableFov);  break;
        case 3: AimFire = boolean;SendFeatuere(m_Features::g_AimFire, AimFire);  break;
        case 4: AimScope = boolean;SendFeatuere(m_Features::g_AimScope, AimScope);  break;
        case 5: AimCrouch = boolean;SendFeatuere(m_Features::g_AimCrouch, AimCrouch);  break;
        case 6: AimKill = boolean;SendFeatuere(m_Features::g_AimKill, AimKill); break;
        case 7: EspFire = boolean;SendFeatuere(m_Features::g_EspFire, EspFire);  break;
        case 8: EspGranade = boolean;SendFeatuere(m_Features::g_EspGranade, EspGranade);  break;
        case 9: EspAlert = boolean;SendFeatuere(m_Features::g_EspAlert, EspAlert);  break;
        case 10: EspLine = boolean; break;
        case 11: EspBox = boolean; break;
        case 12: EspDistance = boolean; break;
		case 13: EspHealth = boolean; break;
        case 14: EnableFly = boolean; SendFeatuere(m_Features::g_OnFly, EnableFly); break;
        case 15: TPCAR = boolean;SendFeatuere(m_Features::g_TPCAR, TPCAR);  break;
        case 16: TP = boolean;SendFeatuere(m_Features::g_TP, TP);  break;
        case 17: TPF = boolean;SendFeatuere(m_Features::g_TPF, TPF);  break;
        case 18: TPC = boolean;SendFeatuere(m_Features::g_TPC, TPC);  break;
        case 19: ResetGuest = boolean;remove("/storage/emulated/0/com.garena.msdk");SendFeatuere(m_Features::g_ResetGuest, ResetGuest);  break;      
        case 20: Black = boolean;SendFeatuere(m_Features::g_Black, Black); break;
        case 21:
        if (boolean) {
        EspFixed = 0.0f;
        }else {
        EspFixed = tpRange;
        }
        break;
        case 22: Ghost = boolean;SendFeatuere(m_Features::g_Ghost, Ghost);  break;
        case 23: EspName = boolean; break;
        case 24: MedkitRun = boolean;SendFeatuere(m_Features::g_MedkitRun, MedkitRun); break;
        case 25: Esp_ = boolean; break;
        /*case 1: AimFire = boolean;SendFeatuere(m_Features::g_AimFire, AimFire);  break;
        case 2: AimScope = boolean;SendFeatuere(m_Features::g_AimScope, AimScope);  break;
        case 3: AimVisible = boolean;SendFeatuere(m_Features::g_AimVisible, AimVisible);  break;
        case 4: AimKill = boolean;SendFeatuere(m_Features::g_AimKill, AimKill); break;
		case 5: EspFire = boolean;SendFeatuere(m_Features::g_EspFire, EspFire);  break;
        case 6: EspGranade = boolean;SendFeatuere(m_Features::g_EspGranade, EspGranade);  break;
        case 7: EspAlert = boolean;SendFeatuere(m_Features::g_EspAlert, EspAlert);  break;
        case 8: EspLine = boolean; break;
        case 9: EspBox = boolean; break;
        case 10: EspName = boolean; break;
		case 11: EspDistance = boolean; break;
		case 12: EspHealth = boolean; break;
        case 13: MedkitRun = boolean;SendFeatuere(m_Features::g_MedkitRun, MedkitRun); break;
        case 14: IsSpeed = boolean;SendFeatuere(m_Features::g_IsSpeed, IsSpeed);  break;
        case 15: Speed100xB = boolean;SendFeatuere(m_Features::g_Speed100x, Speed100xB);  break;
       // case 16: UnderCarB = boolean;SendFeatuere(m_Features::g_UnderCar, UnderCarB); break;
        case 17: DoubleGunB = boolean;SendFeatuere(m_Features::g_DoubleGun, DoubleGunB);  break;
        case 18: StoneB = boolean;SendFeatuere(m_Features::g_Stone, StoneB);  break;
		case 19: WallHack = boolean;SendFeatuere(m_Features::g_WallHack, WallHack);  break;
		case 20: Ghost = boolean;SendFeatuere(m_Features::g_Ghost, Ghost);  break;
        case 21: ResetGuest = boolean;remove("/storage/emulated/0/com.garena.msdk");SendFeatuere(m_Features::g_ResetGuest, ResetGuest);  break;
		
		case 27: Increase = boolean; break;
        
        case 29: f1 = boolean;SendFeatuere(m_Features::g_f1, f1); break;
        case 30: f2 = boolean;SendFeatuere(m_Features::g_f2, f2); break;
        case 31: f3 = boolean;SendFeatuere(m_Features::g_f3, f3);
        break;
        case 32: f4 = boolean;SendFeatuere(m_Features::g_f4, f4); break;
        case 33: f5 = boolean;SendFeatuere(m_Features::g_f5, f5); break;
        case 34: f6 = boolean;SendFeatuere(m_Features::g_f6, f6); break;*/
        
     }
}
extern "C" {
JNIEXPORT void  JNICALL
Java_fin_java_offset_editor(JNIEnv *env, jclass type, jint num, jstring input, jstring output) {
	switch (num){
		case 1:
			const char *cstr = env->GetStringUTFChars(input, NULL);
            std::string str = std::string(cstr);
		   
 
			//stringg = offset;
		break;
	}
}}

void Size(
JNIEnv *env, jclass type, jint num, jfloat Size) {
    switch (num){
        
           case 0:        
            Fov_Aim = Size;
            SendFeatuerevalue(m_Features::g_AimFov, true,Fov_Aim);
            break;
        case 1:
            if (Size == 0) {
            maincolor = Color::Red();
            } else if (Size == 1) {
            maincolor = Color::Yellow();
            } else if (Size == 2) {
            maincolor = Color::Purple();
            } else if (Size == 3) {
            maincolor = Color::Black();
            } else if (Size == 4) {
            maincolor = Color::Green();
            } else if (Size == 5) {
            maincolor = Color::Blue();
            } else if (Size == 6) {
            maincolor = Color::Gray();
            } else if (Size == 7) {
            maincolor = Color::White();
            } else if (Size == 8) {
            maincolor = Color::Magenta();
            } else if (Size == 9) {
            maincolor = Color::Cyan();
            } else if (Size == 10) {
            maincolor = Color::DeepPink();
            } 
            break;
            case 2:
            fly = Size;
            SendFeatuerevalue(m_Features::g_fly,true,fly );
            break;
            case 3:
            flyspeed = Size;
            SendFeatuerevalue(m_Features::g_flyspeed, true,flyspeed);
            break;
            case 4:
             tpRange = Size;
             SendFeatuerevalue(m_Features::g_tpRange, true,tpRange);
            break;
        case 5:
            if(Size == 0){
				SendFeatuere(m_Features::g_cameraview, cameraview);
			}		
			if(Size == 1){
				SendFeatuere(m_Features::g_cameraview1, cameraview1);
			}	
			if(Size == 2){
				SendFeatuere(m_Features::g_cameraview2, cameraview2);
			}	
			if(Size == 3){
				SendFeatuere(m_Features::g_cameraview3, cameraview3);
			}	
				if(Size == 4){
				SendFeatuere(m_Features::g_cameraview4, cameraview4);
			}	
					if(Size == 5){
				SendFeatuere(m_Features::g_cameraview5, cameraview5);
			}	
				if(Size == 6){
				SendFeatuere(m_Features::g_cameraview6, cameraview6);
			}				
        break;
        case 6:
          //  PlYerSpeed = Size;        
          SendFeatuerevalue(m_Features::g_PlYerSpeed,true,Size);
         break;
         case 7:
             SendFeatuerevalue(m_Features::g_Recoil,true,Size);
             break;
        /*case 3:
            if (Size == 0) {
            espLinePosition = 0.0f;
            } else if (Size == 1) {
            espLinePosition = 541.0f;
            } else if (Size == 2) {
            espLinePosition = 1000.0f;
            } else if (Size == 3) {
            FlyPosX = 3;
            } else if (Size == 4) {
            FlyPosX = 4;
            }
            SendFeatuere(m_Features::g_CarPos, FlyPosX);
        break;
            
            
            case 7:
            
            break;
            case 8:
                Fov_Aim = Size;
                SendFeatuerevalue(m_Features::g_AimFov, true,Fov_Aim);
             break;*/
        
     }
}


bool isValidPlayer(PlayerData data) {
    return (data.HeadLocation != Vector3::Zero());
}
bool isValidCloseEnemy(PlayerData data) {
    return (data.CloseEnemyHeadLocation != Vector3::Zero());
}
string getPresentDateTime()
{
    time_t tt;
    struct tm *st;

    time(&tt);
    st = localtime(&tt);
    return asctime(st);
}
ESP espOverlay;
void DrawESP(ESP esp, int screenWidth, int screenHeight) {
    
    float mScale = (float) screenHeight / (float) 1080;

    //esp.DrawText(maincolor, 2.0f, (prince.time),Vector3(screenWidth/7,screenHeight/20),  30.0f);
  // esp.ModernText(Vector3(screenWidth - 691,screenHeight - 101),340,Color::Red(),7,70);  
 //  esp.DrawFilledRect(Color::Black(),Vector3(screenWidth / 2,screenHeight / 1.0f),screenWidth-350,screenHeight-100);
	esp.DrawText(Color::White(), 2, ("@PRINCEINJECTOR"),  Vector3(screenWidth / 2,screenHeight / 1.03f + 10.0f),  30.0f);//10.0f
         
    
        if (isConnected()) {
            Response response = getData(screenWidth, screenHeight);
            if(response.Success) {
                
                int count = response.PlayerCount;
                if(count > 0) {
					   PlayerData localPlayer = response.Players[0];
                    for(int i = 0; i < count; i++) {
						
                        PlayerData player = response.Players[i];
                        if(!isValidPlayer(player)){ continue; }
						//void* closestEnemy = players->getValues()[u];
                        Vector3 Head = player.HeadLocation;
                        char bx[20];
                        float Tamanho = 0.0f;
                        if (player.Distance2 > 10.0f) {
                            Tamanho = 10.0f;
                            } else if (player.Distance2 > 20.0f) {
                            Tamanho = 0.0f;
                            }
                        Vector3 End = Head;
						Vector3 PositionHead = Head - espPosition;
                        Vector3 End2 = player.ToeLocation;
                        float boxHeight = abs(Head.Y - player.ToeLocation.Y);
                        float boxWidth = boxHeight * 0.65f;
                        Rect PlayerRect(Head.X - (boxWidth / 2), (screenHeight - Head.Y), boxWidth, boxHeight);
                        
                        
                        if (EspLine) {
                            if (!player.get_IsDieing) {
                                esp.DrawLine2(maincolor, 4, Vector2((screenWidth / 2), espLinePosition), Vector2((screenWidth - (screenWidth - Head.X)), (screenHeight - Head.Y - 8.0f)));
                            } else {
                                esp.DrawLine2(Color::Red(), 4, Vector2((screenWidth / 2), espLinePosition), Vector2((screenWidth - (screenWidth - Head.X)), (screenHeight - Head.Y - 8.0f)));
                            }
                        }
                        
                        if (EspBox) { 
                           if (!player.get_IsDieing) {
								esp.DrawBox(maincolor, 2, PlayerRect);		                               
                                } else {
                                esp.DrawBox(Color::Red(), 2, PlayerRect);    
                                }
                           /* esp.DrawBox4Line(End.X - (Width / 2), (screenHeight - End.Y - 10.0f), Width, Height + Tamanho,player.get_IsDieing ? maincolor : Color::White(), espSize);*/
                        }
						
                  
                                   
						if (EspName) {
							if (!player.get_IsDieing) {                                
							esp.DrawText(maincolor, 2, char_to_string(player.PlayerName[i]),Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height + 50.5f), 15);
                        } else {
                            
                            esp.DrawText(Color::Red(), 2, char_to_string(player.PlayerName[i]),Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height + 50.5f), 15);
                        }
                        
						}
						
						
						
						string str2 = to_string ( player.Health ) ;
						string str1 = to_string ( response.PlayerCount ) ;
						if (EspDistance) {
                          //  esp.ModernText(Vector3(PlayerRect.x + (PlayerRect.width / 30) ,PlayerRect.y),100,maincolor,5,50);      
                            
							char buffer[30];
							sprintf(buffer, "PLAYER DISTANCE %.2f", player.Distance2);			
                            esp.DrawText(maincolor, 2, buffer ,Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height - 200.5f), espSize);
                                esp.DrawText(maincolor, 25.0f, ("Total Player " + str1 ),Vector3(screenWidth / 2, screenHeight / 6),  espSize);		
                          if (!player.get_IsDieing) {
                             // esp.DrawText(maincolor, 2, "😎",Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height - 50.5f), 15);
                             //esp.DrawText(maincolor, 2, "Player : Alive",Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height - 170.5f), espSize);
                             if(player.isBot){
                             esp.DrawText(maincolor, 2, "Player : Alive",Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height - 170.5f), espSize);    
                             esp.DrawText(maincolor, 2, "Player : Bot",Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height - 140.5f), espSize);
                             } else {
                             esp.DrawText(maincolor, 2, "Player : Alive",Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height - 170.5f), espSize);    
                             esp.DrawText(maincolor, 2, "Player : Real",Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height - 140.5f), espSize);   
                             }
                          } else {
                            //  esp.DrawText(maincolor, 2, "😎",Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height - 50.5f), 15);
                            esp.DrawText(Color::Red(), 2, "Player : Knock",Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height - 170.5f), espSize);
                            
                          }
						}
						
						
						if (EspHealth) {
							
							esp.DrawHorizontalHealthBar(Vector3(PlayerRect.x + (PlayerRect.width / 2),PlayerRect.y + PlayerRect.height - 215.5f), 100, 200, player.Health);
							
						}
                        if(Esp_){
                           // esp.DrawBox(Color::Black(), 50, PlayerRect);
                        }
						
                    }
                }
            }
        }
    }
extern "C"
JNIEXPORT void JNICALL
Java_com_joel_ffh4xinject_FloaterHS_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
    espOverlay = ESP(env, espView, canvas);
    
    if (espOverlay.isValid()){
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}

/*extern "C"
void DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
    espOverlay = ESP(env, espView, canvas);
    if (espOverlay.isValid()){
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}*/

jstring T1(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF(OBFUSCATE("PRINCE INJECTOR"));
	}

extern "C" {
bool IsConnected(JNIEnv *env, jobject thiz) {
     return client.connected;
    }
}

/*extern "C"
void Init(JNIEnv *env, jobject thiz) {
    startClient();
}*/
extern "C"
JNIEXPORT jint JNICALL
Java_com_joel_ffh4xinject_FloaterHS_Init(JNIEnv *env, jclass type) {
   return startClient();
}
extern "C"
void Stop(JNIEnv *env, jobject type) {
    stopClient();
}
extern "C" {
JNIEXPORT void  JNICALL
Java_com_mranygaming_injectv1_floatingWindos_AddTextC(JNIEnv *env, jclass type, jint num, jstring Text,jstring Out) {
    switch (num){  
      case 0:
      MainText = jstring_to_string(env,Text);
      break;
      case 1:
     prince.time = jstring_to_string(env,Text);
      break;
}
}
}
extern "C" {
JNIEXPORT jstring  JNICALL
Java_com_mranygaming_injectv1_floatingWindos_GetStr(JNIEnv *env, jobject thiz, jint num, jstring Text,jstring Out) {
    switch (num){  
      case 1:
       string str = read_file(jstring_to_string(env,Text));
     const char * constConvline = str.c_str();
      // return Out->NewStringUTF(constConvline); 
      break;
}
}
}
extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    jclass c = globalEnv->FindClass(OBFUSCATE("com/joel/ffh4xinject/FloaterHS"));
    if (c != nullptr){
        static const JNINativeMethod menuMethods[] = {
              {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
			   {OBFUSCATE("FUCK"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(T1)},
              {OBFUSCATE("Size"),  OBFUSCATE("(IF)V"), reinterpret_cast<void *>(Size)},
			 // {OBFUSCATE("Edittextt"),  OBFUSCATE("()V"), reinterpret_cast<void *>(Edittextt)},
              {OBFUSCATE("Switch"),  OBFUSCATE("(IZ)V"), reinterpret_cast<void *>(Switch)},
           //  {OBFUSCATE("DrawOn"),  OBFUSCATE("(com/mranygaming/injectv1/Esp2;Landroid/graphics/Canvas;)V"), reinterpret_cast<void *>(DrawOn)},
              {OBFUSCATE("IsConnected"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(IsConnected)},
             // {OBFUSCATE("Init"),  OBFUSCATE("()V"), reinterpret_cast<void *>(Init)},
              {OBFUSCATE("Stop"),  OBFUSCATE("()V"), reinterpret_cast<void *>(Stop)},
        };
        int mm = globalEnv->RegisterNatives(c, menuMethods, sizeof(menuMethods) / sizeof(JNINativeMethod));
        if (mm != JNI_OK) {
            LOGE(OBFUSCATE("Menu methods error"));
            return mm;
        }
    } else{
        LOGE(OBFUSCATE("JNI error"));
        return JNI_ERR;
    }
    return JNI_VERSION_1_6;
}
