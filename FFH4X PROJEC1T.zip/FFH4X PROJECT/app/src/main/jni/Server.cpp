#include <jni.h>
#include <iostream>
#include <sstream>
#include <fstream>
#define libil2cpp OBFUSCATE("libil2cpp.so")
#define libunity OBFUSCATE("libunity.so")
#include "images.h"
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "DarkSideEsp/Color.hpp"
#include "Includes/Macros.h"
#include "Unity/Unity.h"
#include "DarkHooks.h"
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"
#include "convert.h"
#include <SOCKET/server.h>
#include <algorithm>    // find



int pLoopDamage = 0;
int WorkTakeDamage = 0;
int LoopFire = 0;
bool StartFire = true;
bool StopFire = false;

struct Uri
{
public:
std::wstring QueryString, Path, Protocol, Host, Port;

static Uri Parse(const std::wstring &uri)
{
    Uri result;

    typedef std::wstring::const_iterator iterator_t;

    if (uri.length() == 0)
        return result;

    iterator_t uriEnd = uri.end();

    // get query start
    iterator_t queryStart = std::find(uri.begin(), uriEnd, L'?');

    // protocol
    iterator_t protocolStart = uri.begin();
    iterator_t protocolEnd = std::find(protocolStart, uriEnd, L':');            //"://");

    if (protocolEnd != uriEnd)
    {
        std::wstring prot = &*(protocolEnd);
        if ((prot.length() > 3) && (prot.substr(0, 3) == L"://"))
        {
            result.Protocol = std::wstring(protocolStart, protocolEnd);
            protocolEnd += 3;   //      ://
        }
        else
            protocolEnd = uri.begin();  // no protocol
    }
    else
        protocolEnd = uri.begin();  // no protocol

    // host
    iterator_t hostStart = protocolEnd;
    iterator_t pathStart = std::find(hostStart, uriEnd, L'/');  // get pathStart

    iterator_t hostEnd = std::find(protocolEnd, 
        (pathStart != uriEnd) ? pathStart : queryStart,
        L':');  // check for port

    result.Host = std::wstring(hostStart, hostEnd);

    // port
    if ((hostEnd != uriEnd) && ((&*(hostEnd))[0] == L':'))  // we have a port
    {
        hostEnd++;
        iterator_t portEnd = (pathStart != uriEnd) ? pathStart : queryStart;
        result.Port = std::wstring(hostEnd, portEnd);
    }

    // path
    if (pathStart != uriEnd)
        result.Path = std::wstring(pathStart, queryStart);

    // query
    if (queryStart != uriEnd)
        result.QueryString = std::wstring(queryStart, uri.end());

    return result;

}   // Parse
};  // uri
# define HOOK(offset, ptr, orig) MSHookFunction((void *)getAbsoluteAddress(libil2cpp, OBFUSCATE_BNM(offset)), (void *)ptr, (void **)&orig);

struct My_Patches {
MemoryPatch Speed100x, SpeedB, Stone, DoubleGun, UnderCar, WallhackV3, FastReload, MedkitRun1, MedkitRun2;
MemoryPatch Night,Ghost,WallHack;
MemoryPatch b1,b2,b3,b4,b5,cust,autokill,b6,b7,b8,b9,damage,Badge;
MemoryPatch cameraview,cameraview1,cameraview2,cameraview3,cameraview4,cameraview5,cameraview6;
} hexPatches;

bool Black = false;

bool EnableFly = false;
bool autoim = false;
bool AimCrouch = false;
bool EnableFov = false;
bool AimFire = false;
bool AimScope = false;
bool AimVisible = false;
bool AimKill = false;
bool EspGranade = false;
bool EspFire = false;
bool EspAlert = false;
bool EspLine = false;
bool EspBox = false;
bool EspDistance = false;
bool EspName = false;
bool EspHealth = false;
bool SkillCar = false;
bool IsSpeed = false;
bool MedkitRun = false;
bool Speed100xB = false;
bool UnderCarB = false;
bool DoubleGunB = false;
bool StoneB = false;
bool cameraview = false;
bool cameraview1 = false;
bool cameraview2 = false;
bool cameraview3 = false;
bool cameraview4 = false;
bool cameraview5 = false;
bool cameraview6 = false;
bool Ghost = false; 
bool WallHack = false;
bool TP = false;
bool TPCAR = false;
bool TPF = false;
string ppp = "fuck you";
bool TPS = false;
bool TPC = false;
bool sendoffset = false;
bool autokill = false;
bool acces = false;
int flyaltura = 0;
float flyspeed = 0;
int FlyCatapultX = 0;
int FlyPosX = 0;
int FlySpeedX = 0;
float fly = 0;
bool madherchod = false;
bool badge = false;
bool ResetGuest = false;
uintptr_t ofset;
string hexs;
bool Byp = false;
MemoryPatch cus;
float TextSize = 15;
float LineSize = 0.75;
void *Grenade2 = nullptr;
void *Render2 = nullptr;
Color ChangeColor = Color::White();
std::string indetifiq;
float PlYerSpeed = 0.0f;
float NRecoil = 0;
int totalPlayersNum = 0;
enum Mode {
    InitMode = 1,
    HackMode = 2,
    StopMode = 3,
    EspMode = 99,
};
enum FireMode {
    MANUL,  // 0
    AUTO    // 1
};
enum FireStatus {
    NONE,   //0
    FIRING, //1
    CANCEL //2
};
enum m_Features {
    g_EnableAim = 3,
    g_AimFire = 4,
    g_AimScope = 5,
    g_AimVisible = 6,
    g_AimKill = 7,
    g_AimFov = 111,
    g_EspGranade = 8,
    g_EspFire = 119,
    g_EspAlert = 9,
    g_EspLine = 10,
    g_EspBox = 11,
    g_EspName = 12,
    g_EspDistance = 13,
    g_EspHealth = 14,
    g_CarHeight = 112,
    g_CarPos = 113,
    g_CarSpeed = 114,
    g_SkillCar = 15,
    g_FlyHeight = 115,
    g_FlySpeed = 116,
    g_MedkitRun = 16,
    g_IsSpeed = 17,
    g_Speed100x = 18,
    g_UnderCar = 19,
    g_DoubleGun = 20,
    g_Stone = 21,
    g_ResetGuest = 22,
    g_cameraview = 23,
    g_cameraview1 = 24,
    g_cameraview2 = 25,
    g_cameraview3 = 26,
    g_cameraview4 = 27,
    g_cameraview5 = 28,
    g_cameraview6 = 29,
    g_Ghost = 30,
    g_WallHack = 31,
    g_TP = 32,
    g_TPCAR = 33,
    g_TPF = 34,
    g_TPS = 35,
    g_TPC = 36,
    g_sendoffset = 37,
    g_badge = 38,
    g_fly = 39,
    g_flyspeed = 40,
    g_op = 41,
    g_f1 = 42,
    g_f2 = 43,
    g_f3 = 44,
    g_f4 = 45,
    g_f5 = 46,
    g_f6 = 47,
    g_ExtraSeek = 48,
    g_tpRange = 49,
    g_AimAuto = 50,
    g_enableFov = 51,
    g_AimCrouch = 52,
    g_OnFly = 53,
    g_Black = 54,
g_PlYerSpeed = 55,
g_Recoil = 56,
};
struct FlyHack {
    int Fly = 0;
    int FlySpeed = 0;
    float HaruX = 0.0f;
    float HaruY = 0.0f;
    float HaruZ = 0.0f;
    Vector3 MountCam;
}flysaved;

float Fov_Aim = 1;
float Tp = 0;
void *GetClosestEnemy(void *match) {
    if(!match) {
        return nullptr;
    }
    float shortestDistance = 99999.0f;
    float maxAngle;
    if(EnableFov) {
    maxAngle = Fov_Aim;
    } else {
    maxAngle = 1.0f;   
    }
    void* closestEnemy = NULL;
    void* LocalPlayer = GetLocalPlayer(match);
    if(LocalPlayer != nullptr) {
        monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)match + DarkOffsets::Dictionary);        
        for(int u = 0; u < players->getNumValues(); u++) {
            void* Player = players->getValues()[u];
            if(Player != NULL && !get_isLocalTeam(Player) && !get_IsDieing(Player) && get_isVisible(Player) && get_MaxHP(Player)) {
                Vector3 PlayerPos = GetHeadPosition(Player);
                Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
               
                if(AimVisible) {
                    Vector3 targetDir = Vector3::Normalized(PlayerPos - LocalPlayerPos);
                    float angle = Vector3::Angle(targetDir, GetForward(Component_GetTransform(Camera_main()))) * 100.0;
                    if(angle <= maxAngle) {
                        if(angle < shortestDistance) {
                            shortestDistance = angle;
                            closestEnemy = Player;
                            }
                        }
                    
                }
            }
        }
    }
    return closestEnemy;
}
bool ChecagemEnemy(void * enemy){
void* Cristiano = NULL;
Vector3 RotationLocal = Transform_INTERNAL_GetPosition(Component_GetTransform(Camera_main()));
Vector3 EnemyCheck = Transform_INTERNAL_GetPosition(Component_GetTransform(GetHeadCollider(enemy)));
if(!Cristiano_RayVery(RotationLocal, EnemyCheck, 5, &Cristiano)){
return true;
}else{
return false;
}
return false;
}
bool Visible_Check(void * player)
{
    if (player != NULL) 
    {
         void *hitObj = NULL;
         Vector3 CameraLocation = Transform_INTERNAL_GetPosition(Component_GetTransform(Camera_main()));
         Vector3 HeadLocation = Transform_INTERNAL_GetPosition(Component_GetTransform(GetHeadCollider(player)));
         return !Cristiano_RayVery(CameraLocation, HeadLocation, 12, &hitObj);
    }
    return false;
}
void *Pid = nullptr;
void *Stat = nullptr;
/*void (*PlayerNetwork_StartFiring)(void *PlayerID, void *State);
void (_PlayerNetwork_StartFiring)(void *PlayerID, void *State){
    void* CurrentMatch = Curent_Match();
        if(CurrentMatch != nullptr) {
       void* LocalPlayer = GetLocalPlayer(CurrentMatch); 
       if(LocalPlayer != nullptr) {
    Pid = PlayerID;
    Stat = State;
     }
    }
   return PlayerNetwork_StartFiring(PlayerID,State);
}*/
void PlayerNetwork_StartFiring(void *PlayerID, void *State) {
void (*_PlayerNetwork_StartFiring)(void *PlayerID, void *State) = (void (*)(void *, void *))getAbsoluteAddress(libil2cpp,0x13142D8);
    _PlayerNetwork_StartFiring(PlayerID,State);
}
struct DataRemote {
    void *method1 = nullptr;
    int32_t method2 = 0;
    void *method3 = nullptr;
    void *method4 = nullptr;
    int32_t method5 = 0;
    Vector3 method6 = Vector3::Zero();
    Vector3 method7 = Vector3::Zero();
    monoList<float *> method8;
    void *method9 = nullptr;
    int32_t method10 = 0;
}pData;

struct aim 
{
    bool ST = true;
    Vector3 Head = Vector3::Zero();
   // int32_t dmg = 200;
   void *player = nullptr;
}prince;
struct Remote {
    bool AimTiro = false;
    int pLoopMethod1 = 0;
    int pLoopMethod2 = 0;
    bool pStartMethod3 = false;
    bool pStopMethod4 = false;
    int pLoopMethod3 = 0;
    int P = 0;
}pRemote;

/*bool remotekill = false;
int pLoopFireKill = 0;
int loopTakeDamage = 0;
bool pStartFireKill = false;
bool pStopFireKill = false;*/
struct Swap {
    int Weap = 0;
    bool Valied = false;
    monoList<int * > WeaponDic;
}Swap;
void (*SwapWeapon)(int POFFNNMOOBM, bool GDKLMFLNNGM, monoList<int * > HACDOKBPCHJ);
void _SwapWeapon(int POFFNNMOOBM, bool GDKLMFLNNGM, monoList<int * > HACDOKBPCHJ){
    if (AimKill) {
        Swap.Weap = POFFNNMOOBM;
        Swap.Valied=GDKLMFLNNGM;
        Swap.WeaponDic=HACDOKBPCHJ;
    } else {
        Swap.Weap = 0;
    }
}
//void *SwapWeapon(int POFFNNMOOBM, bool GDKLMFLNNGM = false, monoList<int * > HACDOKBPCHJ);
int32_t (*orig_PlayerNetwork_TakeDamage)(void *player, int32_t p_damage, void *get_KillerPlayerID, void *p_info, int32_t WeaponDataID, Vector3 FirePos, Vector3 TargetPos, monoList<float *> CheckParams, void *p_idk1, int32_t p_idk2);
int32_t hook_PlayerNetwork_TakeDamage(void *player, int32_t p_damage, void *get_KillerPlayerID, void *p_info, int32_t WeaponDataID, Vector3 FirePos, Vector3 TargetPos, monoList<float *> CheckParams, void *p_idk1, int32_t p_idk2) {
    if(AimKill) {
        pData.method1 = player;
        pData.method2 = p_damage;
        pData.method3 = get_KillerPlayerID;
        pData.method4 = p_info;
        pData.method5 = WeaponDataID;
        pData.method6 = FirePos;
        pData.method7 = TargetPos;
       
        pData.method8 = CheckParams;
        pData.method9 = p_idk1;
        pData.method10 = p_idk2;        
    //    PlayerNetwork_StartFiring(Pid, Stat);
    
    
  } else {       
        pData. method1 = nullptr;
    }
    return orig_PlayerNetwork_TakeDamage(player, p_damage, get_KillerPlayerID, p_info, WeaponDataID, FirePos, TargetPos, CheckParams, p_idk1, p_idk2);
} 
bool loop1 = false;
            bool loop2 = true;
            bool loop3 = false;
void startAimKill(void *En){   
    void* CurrentMatch = Curent_Match();
        if(CurrentMatch != nullptr) {
       void* LocalPlayer = GetLocalPlayerOrObServer();   
       void* LocalPlayer2 = GetLocalPlayer2(CurrentMatch);
       void* GetWeaponHand = Player_GetWeaponOnHand(LocalPlayer);
       void* GetWeaponHand2 = Player_GetWeaponOnHand(LocalPlayer2);
        if(LocalPlayer != nullptr) {
          void* closestEnemy = En;
          if (ChecagemEnemy(closestEnemy)){  
          PlayerNetwork_StartFiring(LocalPlayer, Player_GetWeaponOnHand(LocalPlayer)); 
          if (GetWeaponHand != nullptr){
             PlayerNetwork_StartFiring(LocalPlayer, GetWeaponHand);   
            PlayerNetwork_StopFire(LocalPlayer, GetWeaponHand); 
        
            orig_PlayerNetwork_TakeDamage(closestEnemy, pData.method2, pData.method3, pData.method4, pData.method5, pData.method6, pData.method7, pData.method8, pData.method9, pData.method10);                    
            PlayerNetwork_StartFiring(LocalPlayer2, GetWeaponHand2);  
            PlayerNetwork_StopFire(LocalPlayer2, GetWeaponHand2); 
              // hook_PlayerNetwork_TakeDamage(closestEnemy, pData.method2, pData.method3/*LocalPlayer*/, pData.method4, pData.method5, pData.method6, pData.method7, pData.method8, pData.method9, pData.method10);
          //  hook_PlayerNetwork_TakeDamage(closestEnemy, pData.method2, pData.method3, pData.method4, pData.method5, pData.method6, pData.method7, pData.method8, pData.method9, pData.method10);           
          
            //PlayerNetwork_StartFiring(LocalPlayer, GetWeaponHand);           
            }
          } else {              
            // PlayerNetwork_StartFiring(LocalPlayer, GetWeaponHand);
          }
         }         
       }
     }
bool StartFires(void *Player,void *Weapon){
    bool loop1 = false;
    bool loop2 = true;
    PlayerNetwork_StartFiring(Player, Weapon);
    if(loop2){
        return true;
        loop2 = false;
    } else {
        return false;
    }
    
}
static void m_TakeDamageKill(void * closestEnemy) {

        if (AimKill && pData.method1 != nullptr) {
        void * pCurrentLocalPlayer = GetLocalPlayerOrObServer();
        void * GetWeaponHand = Player_GetWeaponOnHand(pCurrentLocalPlayer);
if (Visible_Check(closestEnemy)) 
       {
                              if (pLoopDamage > 0) 
               {
                    StartFire = true;
                    StopFire = false;
                    pLoopDamage = 0;
               }
                     void *Target = Component_GetTransform(closestEnemy);
               if (WorkTakeDamage > 2) 
               {
                   //Vector3 Head = Transform_INTERNAL_GetPosition(Target);
                    PlayerNetwork_StopFire(pCurrentLocalPlayer, GetWeaponHand);
                    orig_PlayerNetwork_TakeDamage(closestEnemy, pData.method2, pData.method3, pData.method4, pData.method5, pData.method6, pData.method7, pData.method8, pData.method9, pData.method10);
                    PlayerNetwork_StartFiring(pCurrentLocalPlayer, GetWeaponHand);
                    WorkTakeDamage = 0;
               }
            
               if (LoopFire > 0) 
               {
                     PlayerNetwork_StartFiring(pCurrentLocalPlayer, GetWeaponHand);
                     LoopFire = 0;
               } 
            
               if (StartFire) 
               {
                    if (pCurrentLocalPlayer) 
                    {
                          if (GetWeaponHand) 
                          {
                                PlayerNetwork_StartFiring(pCurrentLocalPlayer, GetWeaponHand);
                          }
                    }
                    StartFire = true;
                    StopFire = false;
               }
             
               if (StopFire) 
               {
                    if (pCurrentLocalPlayer) 
                    {
                          if (GetWeaponHand) 
                          {
                                 PlayerNetwork_StopFire(pCurrentLocalPlayer, GetWeaponHand);
                                  ++WorkTakeDamage;
                          }
                    }
                    StartFire = false;
                    StopFire = true;
               }            
          }
      }
}




void Aimbot(void *LocalPlayer, void *Player) {
void* CurrentMatch = Curent_Match();
  if(CurrentMatch != nullptr) {
     void* LocalPlayer = GetLocalPlayer(CurrentMatch);                        
           if(LocalPlayer != nullptr) {
              void* closestEnemy = GetClosestEnemy(CurrentMatch);
             if(closestEnemy != nullptr) {
                   Vector3 EnemyLocation = GetHeadPosition(closestEnemy);
                    Vector3 PlayerLocation = CameraMain(LocalPlayer);
                    Quaternion PlayerLook = GetRotationToLocation(EnemyLocation, 0.1f, PlayerLocation);                  
                    Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
                    Vector3 PlayerHeadPos = GetHeadPosition(closestEnemy);
                    float distance = Vector3::Distance(PlayerHeadPos, LocalPlayerPos);
                 // Stat = ;
                   Pid = closestEnemy;
                      ++WorkTakeDamage;
				++pLoopDamage;
                   bool visivel = Visible_Check(closestEnemy);
                          if (AimKill) 
                          {            
                          int z =0;
                          //m_TakeDamageKill(closestEnemy);
                          //write_file("/storage/emulated/0/Android/GodsTeam.ini","m_RemoteKill01");
                        m_TakeDamageKill(closestEnemy);
                        }
                        // PlayerNetwork_StartFiring(LocalPlayer, Player_GetWeaponOnHand(LocalPlayer)); 
                        /*  } else {
                            //write_file("/storage/emulated/0/Android/GodsTeam.ini","m_RemoteKill00");  
                          }*/
         if (AimScope && get_IsSighting(LocalPlayer)) {
             set_aim(LocalPlayer, PlayerLook);
            }
         if (AimFire && get_IsFiring(LocalPlayer)) {
             set_aim(LocalPlayer, PlayerLook);
                          
                 }
          if (AimCrouch && get_IsCrouching(LocalPlayer)) {
              set_aim(LocalPlayer, PlayerLook);
           } 
           if (autoim){
               set_aim(LocalPlayer, PlayerLook);
           }
            
              }
           }
        }
     }
  
void (*UpdateLine)(void *instance);
void _UpdateLine(void *instance) {
    if (instance != NULL) {
        Grenade2 = instance;
        *(bool *)((uintptr_t)instance + 0xC) = true;
        Render2 = *(void **)((long)instance + 0x10);
       }
       UpdateLine(instance);
     }
     
void *GetEspEnemy(void *match) {
    if(!match) {
        return nullptr;
    }
    float shortestDistance = 99999.0f;
    float maxAngle = 99999.0f;
    void* closestEnemy = NULL;
    void* LocalPlayer = GetLocalPlayer(match);
    if(LocalPlayer != nullptr) {
        monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)match + DarkOffsets::Dictionary);
        for(int u = 0; u < players->getNumValues(); u++) {
            void* Player = players->getValues()[u];
            if(Player != NULL && !get_isLocalTeam(Player) && !get_IsDieing(Player) && get_isVisible(Player) && get_MaxHP(Player)) {
                Vector3 PlayerPos = GetHeadPosition(Player);
                Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
                    Vector3 targetDir = Vector3::Normalized(PlayerPos - LocalPlayerPos);
					//Vector3 PlayerPos = GetHeadPosition(closestEnemy);
    //Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
     
	Vector3 CenterWS = GetAttackableCenterWS(LocalPlayer);
                
	  if(EspFire){
		  void *imo = get_imo(LocalPlayer);
                            if (imo != NULL ) {
                                set_esp(imo, CenterWS, PlayerPos);
                                 }
	  }
                    float angle = Vector3::Angle(targetDir, GetForward(Component_GetTransform(Camera_main()))) * 100.0;
                    if(angle <= maxAngle) {
                        if(angle < shortestDistance) {
                            shortestDistance = angle;
                            closestEnemy = Player;
                            
                    }
                }
            }
        }
    }
    return closestEnemy;
}

void DrawConfigEsp(void *LocalPlayer, void *Player) {
void* CurrentMatch = Curent_Match();
  if(CurrentMatch != nullptr) {
     void* LocalPlayer = GetLocalPlayer(CurrentMatch);                        
      if(LocalPlayer != nullptr) {
         void* closestEnemy = GetEspEnemy(CurrentMatch);
            if(closestEnemy != nullptr) {
                
    Vector3 PlayerPos = GetHeadPosition(closestEnemy);
    Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
	Vector3 CenterWS = GetAttackableCenterWS(LocalPlayer);
                
    
	  if(EspFire){
		  void *imo = get_imo(LocalPlayer);
                            if (imo != NULL ) {
                                set_esp(imo, CenterWS, PlayerPos);
                                 }
	  }

      float distance = Vector3::Distance(LocalPlayerPos, PlayerPos);
      if (EspAlert) {
          void *ui = CurrentUIScene();
            if (ui != NULL) {
                int vida = GetHp(closestEnemy);
                monoString *nick = get_NickName(closestEnemy);
                monoString *distances = U3DStrFormat(distance,vida);
                monoString *distances2 = U3DStrPlayer2(distance,vida);
              //  monoString fuk = GetWeaponName(Player);
                bool isPlayerBot = *(bool *) ((uintptr_t) closestEnemy + DarkOffsets::IsClientBot);
                if (isPlayerBot) {
                    AddTeammateHud(ui, nick, distances);
                    } else {
                    AddTeammateHud(ui, nick, distances2);
                    
                   }
                }
             }
          }
       }
    }
 }
 void *GetClosestEnemyTP(void *match) {
    if(!match) {
        return nullptr;
    }
    float shortestDistance = 99999.0f;
    float maxAngle;
    if(EnableFov) {
    maxAngle = Tp;
    } else {
    maxAngle = 1.0f;   
    }
    void* closestEnemy = NULL;
    void* LocalPlayer = GetLocalPlayer(match);
    if(LocalPlayer != nullptr) {
        monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)match + DarkOffsets::Dictionary);
        for(int u = 0; u < players->getNumValues(); u++) {
            void* Player = players->getValues()[u];
            if(Player != NULL && !get_isLocalTeam(Player) && !get_IsDieing(Player) && get_isVisible(Player) && get_MaxHP(Player)) {
                Vector3 PlayerPos = GetHeadPosition(Player);
                Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
               
                if(AimVisible) {
                    Vector3 targetDir = Vector3::Normalized(PlayerPos - LocalPlayerPos);
                    float angle = Vector3::Angle(targetDir, GetForward(Component_GetTransform(Camera_main()))) * 100.0;
                    if(angle <= maxAngle) {
                        if(angle < shortestDistance) {
                            shortestDistance = angle;
                            closestEnemy = Player;
                            }
                        }
                    
                }
            }
        }
    }
    return closestEnemy;
}
void CarSkill(void *LocalPlayer, void *Player) {
void *CurrentMatch = Curent_Match();
      if(CurrentMatch != nullptr) {
     void* LocalPlayer = GetLocalPlayer2(CurrentMatch);    
     void* LocalPlayer2 = GetLocalPlayer2(CurrentMatch);
           if(LocalPlayer != nullptr) {
              void* closestEnemy = GetClosestEnemy(CurrentMatch);
             if(closestEnemy != nullptr) {
        Vector3 PlayerPos = GetHeadPosition(closestEnemy);
		bool dirigindo = LocalPlayer;
			
		if (TPCAR && dirigindo) {

    // INICIO DO TELEPORTE
    void *_TeleCarTP = Component_GetTransform(closestEnemy);
    if (_TeleCarTP != NULL) {
        Vector3 TeleCarTP =
                Transform_INTERNAL_GetPosition(_TeleCarTP) - (GetForward(_TeleCarTP) * 0.0f);

        void* LocalCar = GetLocalCar(LocalPlayer);
        if (LocalCar != NULL) {

            Transform_INTERNAL_SetPosition(Component_GetTransform(LocalCar), Vvector3(TeleCarTP.X, TeleCarTP.Y+ 1.0, TeleCarTP.Z ));

        }

    }
    // FIM DO TELEPORTE


}
      void *_MountTF = Component_GetTransform(closestEnemy);

      if (TP) {
          if (_MountTF != NULL) {
                Vector3 MountTF =Transform_INTERNAL_GetPosition(_MountTF) -(GetForward(_MountTF) * 0.0f);
                Transform_INTERNAL_SetPosition(Component_GetTransform(LocalPlayer),Vvector3(MountTF.X+1.4f, MountTF.Y + 1.4f, MountTF.Z+1.4f));
                Transform_INTERNAL_SetPosition(Component_GetTransform(Camera_main()),Vvector3(MountTF.X+1.4f, MountTF.Y + 1.4f, MountTF.Z+1.4f));
            }
	//  Transform_INTERNAL_SetPosition(Component_GetTransform(LocalPlayer), Vvector3(PlayerPos.X, PlayerPos.Y + 0.0f, PlayerPos.Z));
      }
	   if (TPS && get_IsSighting(LocalPlayer)) {
		 	if (_MountTF != NULL) {
                Vector3 MountTF =Transform_INTERNAL_GetPosition(_MountTF) -(GetForward(_MountTF) * 0.0f);
                Transform_INTERNAL_SetPosition(Component_GetTransform(LocalPlayer),Vvector3(MountTF.X+1.4f, MountTF.Y + 1.4f, MountTF.Z+1.4f));
                Transform_INTERNAL_SetPosition(Component_GetTransform(Camera_main()),Vvector3(MountTF.X+1.4f, MountTF.Y + 1.4f, MountTF.Z+1.4f));
            }   
	   }
	   if (TPF && get_IsFiring(LocalPlayer)){
		   if (_MountTF != NULL) {
               Vector3 MountTF =Transform_INTERNAL_GetPosition(_MountTF) -(GetForward(_MountTF) * 0.0f);
                Transform_INTERNAL_SetPosition(Component_GetTransform(LocalPlayer),Vvector3(MountTF.X+1.4f, MountTF.Y + 1.4f, MountTF.Z+1.4f));
                Transform_INTERNAL_SetPosition(Component_GetTransform(Camera_main()),Vvector3(MountTF.X+1.4f, MountTF.Y + 1.4f, MountTF.Z+1.4f));
            }
	   }
	   if (TPC && get_IsCrouching(LocalPlayer)) {
		   if (_MountTF != NULL) {
               Vector3 MountTF =Transform_INTERNAL_GetPosition(_MountTF) -(GetForward(_MountTF) * 0.0f);
                Transform_INTERNAL_SetPosition(Component_GetTransform(LocalPlayer),Vvector3(MountTF.X+1.4f, MountTF.Y + 1.4f, MountTF.Z+1.4f));
                Transform_INTERNAL_SetPosition(Component_GetTransform(Camera_main()),Vvector3(MountTF.X+1.4f, MountTF.Y + 1.4f, MountTF.Z+1.4f));
            }
	   }
    }
 }
  }}


void (*DarkUpdateX)(void *componentPlayer);
void *get_DarkSideC = nullptr;
void *get_DarkSideE(void *DarkSideX69) {
      get_DarkSideC = DarkSideX69;
      return get_DarkSideC;
}

void _DarkUpdateX(void *player) {
  if (player != NULL) {
        void *current_match = Curent_Match();
        if (current_match != NULL) {
            void *local_player = Current_Local_Player();
            if (local_player == NULL) {
                local_player = GetLocalPlayerOrObServer();
            }
            if (local_player != NULL) {
                void *fakeCamPlayer = get_MyFollowCamera(local_player);
                void *fakeCamEnemy = get_MyFollowCamera(player);
                if (fakeCamPlayer != NULL && fakeCamEnemy != NULL) {
                    void *fakeCamPlayerTF = Component_GetTransform(fakeCamPlayer);
                    void *fakeCamEnemyTF = Component_GetTransform(player);
                    if (fakeCamPlayerTF != NULL && fakeCamEnemyTF != NULL){
                        Vector3 fakeCamPlayerPos = Transform_INTERNAL_GetPosition(fakeCamPlayerTF);
                        Vector3 fakeCamEnemyPos = Transform_INTERNAL_GetPosition(fakeCamEnemyTF);
                        float distance = Vector3::Distance(fakeCamPlayerPos, fakeCamEnemyPos);
                        if (player != local_player){
                            if (distance > 1.6f) {
                                bool isSameTeam = get_isLocalTeam(player);
                                bool isVisible = get_isVisible(player);
                                bool isDieing = get_IsDieing(player);
                                bool isDead = get_IsDead(player);
                                if (!isSameTeam && isVisible && !isDieing && !isDead) {
                                Aimbot(local_player, player);
                               CarSkill(local_player, player);
                               DrawConfigEsp(local_player, player);
                               
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
         get_DarkSideE(player);
  DarkUpdateX(player);
}


struct Request {
    int Mode;
    bool m_IsOn;
    int value;
    int screenWidth;
    int screenHeight;
};

#define maxplayerCount 54

struct PlayerData {
    char PlayerName[64];
    float Health;
    float Distance2;
    bool get_IsDieing;
    bool isBot;
    Vector3 CloseEnemyHeadLocation;
    Vector3 HeadLocation;
    Vector3 ToeLocation;
    Vector2 RShoulder;
    Vector3 LShoulder;
    Vector3 Toe;
    Vector3 Hip;
    Vector3 Head;
    int x;
    int y;
    int z;
    int id;
    int h;
    char debug[60];
};

struct Response {
    bool Success;
    int PlayerCount;
    PlayerData Players[maxplayerCount];
};

SocketServer server;

int InitServer() {
    if (!server.Create()) { return -1; }
    if (!server.Bind()) { return -1; }
    if (!server.Listen()) { return -1; }
    return 0;
}

void createDataList(Response& response) {
    response.PlayerCount = 0;
    void* DarkSide = get_DarkSideC;
    if (DarkSide != nullptr) {
        void *current_Match = Curent_Match();
        void* local_player = GetLocalPlayer(current_Match);
        if (local_player != nullptr && current_Match != nullptr) {
            monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)current_Match + DarkOffsets::Dictionary);
            
            void *camera = Camera_main();
            if (players != nullptr && camera != nullptr) {
                totalPlayersNum=players->getNumValues();
                for(int u = 1; u < players->getNumValues(); u++) {
                    PlayerData* data = &response.Players[response.PlayerCount];
                    void* closestEnemy = players->getValues()[u];
                    if (closestEnemy != local_player && closestEnemy != nullptr && get_isVisible(closestEnemy) && !get_isLocalTeam(closestEnemy)) {
                        // GET OUR VECTOR
                      
                       Vector3 Toe = WorldToScreenPoint(camera, GetToePosition(closestEnemy));
                        if (Toe.Z < -0) continue;
                        Vector3 Head = WorldToScreenPoint(camera,GetHeadPosition(closestEnemy));
                        if (Head.Z < -0) continue;
                     
                             //GET PLAYER NAME
                                          
                                          monoString *name = get_NickName(closestEnemy);

                                          if(name != NULL) {
                                          int nick_Len = name ->getLength();
                                          std::string name1;      
                                          int i;
                                          for(i = 0; i < nick_Len; i++) {
                                          char data = get_Chars(name, i);
                                          name1 += isascii(data) ? data : '?';                                          
                                          //data->PlayerName = data;    
                                          }
                                          std::string nickname3;
                                          nickname3 += name1;
                                          data->PlayerName[i] = string_to_char(nickname3);
                                          //data->PlayerName[u] = string_to_char(nickname3);
                                         // write_file("/mnt/runtime/user"+int_to_string(i),nickname3);
                                         } 
                                       
                     data->Distance2 = Vector3::Distance(GetHeadPosition(local_player), GetHeadPosition(closestEnemy));
                     data->Health = GetHp(closestEnemy);
                       data->HeadLocation = Head;
                     data->ToeLocation = Toe;
					   data->get_IsDieing = get_IsDieing(closestEnemy); 
						data->isBot = *(bool *) ((uintptr_t) closestEnemy + DarkOffsets::IsClientBot);
                        response.PlayerCount++;
                        pRemote.P = response.PlayerCount;
                        if (response.PlayerCount == maxplayerCount) {
                            continue;
                        }
                    }
                }
            }
        }
    } 
}

bool (*get_IsMove)(void* _this);
bool _get_IsMove(void* _this) {
  if (_this != NULL) {
   if (flyspeed > 0 || fly > 0) {
            return true;
        }
    }
    return get_IsMove(_this);
}


float (*GetSpecialRunSpeedScale)(void *instance);
float _GetSpecialRunSpeedScale(void *instance) {
    if (instance != NULL) {
     if (PlYerSpeed > 0) {
      return PlYerSpeed;
      }
    }
    return GetSpecialRunSpeedScale(instance);
}
float (*GetRunSpeed)(int *PMGBACFJIHO);
float _GetRunSpeed(int *PMGBACFJIHO){
 if(PMGBACFJIHO != NULL){            
  if(PlYerSpeed == 1){    
   return 0.9;
  } else if(PlYerSpeed == 2){
   return 1.0;
  } else if(PlYerSpeed == 3){
   return 1.80;
  } else if(PlYerSpeed == 4){
   return 50;
      }
  //
 }
 return GetRunSpeed(PMGBACFJIHO);
}
void (*set_FSModeUseMedikitFasterRate)(float IMGNBGJDAHG);
void _set_FSModeUseMedikitFasterRate(float IMGNBGJDAHG){
    if(IMGNBGJDAHG != NULL){
        if(MedkitRun){
           _set_FSModeUseMedikitFasterRate(0.1f);
        }
    }
    return set_FSModeUseMedikitFasterRate(IMGNBGJDAHG);
}
bool(*Guest)(void* _this);
bool _Guest(void* _this){
    if (ResetGuest){
      return true; 
    }
    return Guest(_this);
}
bool(*Badge)(void* _this);
bool _Badge(void* _this){
    if (badge){
      return true; 
    }
    return Badge(_this);
}

void *CreateServer(void *) {
    if (InitServer() == 0) {
        if (server.Accept()) {
            Request request{};
            while (server.receive((void*)&request) > 0) {
                Response response{};
                if (request.Mode == Mode::InitMode) {
                    response.Success = true;
                    Byp = true;
                } else if (request.Mode == Mode::HackMode) {      
   
                    response.Success = true;
                } else if (request.Mode == m_Features::g_AimAuto) {
                    autoim = request.m_IsOn;
                }else if (request.Mode == m_Features::g_AimFire) {
                    AimFire = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_AimScope) {
                    AimScope = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_AimCrouch) {
                    AimCrouch = request.m_IsOn;
                  
                    response.Success = true;
                }else if (request.Mode == m_Features::g_EnableAim) {
                    AimVisible = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_AimKill) {       
                    AimKill = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_AimFov) {
                    Fov_Aim = request.value;
                    response.Success = true;
                }else if (request.Mode == m_Features::g_enableFov) {
                    EnableFov = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_EspFire) {
                    EspFire = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_EspGranade) {
                    EspGranade = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_EspAlert) {
                    EspAlert = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == Mode::EspMode) {
                 Black = true;
                  createDataList(response);
                    response.Success = true;
                } else if (request.Mode == m_Features::g_EspLine) {
                    EspLine = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_EspBox) {
                    EspBox = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_EspName) {
                    EspName = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_EspDistance) {
                    EspDistance = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_EspHealth) {
                    EspHealth = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_MedkitRun) {
                    MedkitRun = request.m_IsOn;
                    response.Success = true;
                    if (MedkitRun) {
                        hexPatches.MedkitRun1.Modify();
                        hexPatches.MedkitRun2.Modify();
                    } else {
                        hexPatches.MedkitRun1.Restore();
                        hexPatches.MedkitRun2.Restore();
                    }
                } else if (request.Mode == m_Features::g_PlYerSpeed) {
                    PlYerSpeed = request.value;
                  /*  IsSpeed = request.m_IsOn;
					if (IsSpeed){
						hexPatches.Night.Modify();
					} else {
						hexPatches.Night.Restore();
					}*/
                    response.Success = true;
                } else if (request.Mode == m_Features::g_cameraview) {               
                cameraview = request.m_IsOn;
                hexPatches.cameraview1.Restore();
                 response.Success = true;
               } else if (request.Mode == m_Features::g_cameraview1) {               
                cameraview1 = request.m_IsOn;
                hexPatches.cameraview1.Modify();
                 response.Success = true;
               } else if (request.Mode == m_Features::g_cameraview2) {          
                cameraview2 = request.m_IsOn;
                hexPatches.cameraview2.Modify();              
                 response.Success = true;
               }else if (request.Mode == m_Features::g_cameraview3) {            
               cameraview3 = request.m_IsOn;
                hexPatches.cameraview3.Modify();               
                 response.Success = true;
               }else if (request.Mode == m_Features::g_cameraview4) {               
                cameraview4 = request.m_IsOn;
                hexPatches.cameraview4.Modify();
                 response.Success = true;
               }else if (request.Mode == m_Features::g_cameraview5) {           
                cameraview5 = request.m_IsOn;              
                hexPatches.cameraview5.Modify();             
                 response.Success = true;
               }else if (request.Mode == m_Features::g_cameraview6) {             
                cameraview6 = request.m_IsOn;
                hexPatches.cameraview6.Modify();
                 response.Success = true;
               }else if (request.Mode == m_Features::g_UnderCar) {
                    UnderCarB = request.m_IsOn;
                    response.Success = true;
                    if (UnderCarB) {
                        hexPatches.UnderCar.Modify();
                    } else {
                        hexPatches.UnderCar.Restore();
                    }
                } else if (request.Mode == m_Features::g_DoubleGun) {
                    DoubleGunB = request.m_IsOn;
                    response.Success = true;
                    if (DoubleGunB) {
                        hexPatches.DoubleGun.Modify();
                    } else {
                        hexPatches.DoubleGun.Restore();
                    }
                } else if (request.Mode == m_Features::g_Stone) {
                    StoneB = request.m_IsOn;
                    response.Success = true;
                    if (StoneB) {
                        hexPatches.Stone.Modify();
                    } else {
                        hexPatches.Stone.Restore();
                    }
                } else if (request.Mode == m_Features::g_WallHack) {
                    WallHack = request.m_IsOn;
                    response.Success = true;
                    if (WallHack) {
                        hexPatches.WallHack.Modify();
                    } else {
                        hexPatches.WallHack.Restore();
                    }
                } else if (request.Mode == m_Features::g_Ghost) {
                    Ghost = request.m_IsOn;
                    response.Success = true;
                    if (Ghost) {
                        hexPatches.Ghost.Modify();
                    } else {
                        hexPatches.Ghost.Restore();
                    }
                } else if (request.Mode == m_Features::g_ResetGuest) {
                    ResetGuest = request.m_IsOn;
                    response.Success = true;
                }else if (request.Mode == m_Features::g_TP) {
                   TP = request.m_IsOn;
                    response.Success = true;
                }else if (request.Mode == m_Features::g_TPCAR) {
                TPCAR = request.m_IsOn;
                    response.Success = true;
                }else if (request.Mode == m_Features::g_TPF) {
                    TPF = request.m_IsOn;
                    response.Success = true;
                }else if (request.Mode == m_Features::g_TPS) {
                  TPS = request.m_IsOn;
                    response.Success = true;
                }else if (request.Mode == m_Features::g_TPC) {
                  TPC = request.m_IsOn;
                    response.Success = true;
                }else if (request.Mode == m_Features::g_tpRange) {
                    Tp = request.value;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_badge) {
                  badge = request.m_IsOn;
                    response.Success = true;
                } else if (request.Mode == m_Features::g_fly) {
                  
                    flysaved.Fly = request.value;
                    
                response.Success = true;
                }else if (request.Mode == m_Features::g_flyspeed) {
                    
                     flysaved.FlySpeed = request.value;
                     
                response.Success = true;
                }else if (request.Mode == m_Features::g_Black) {
                   Black = request.value;
                   response.Success = true;
                }else if (request.Mode == m_Features::g_OnFly) {
                   EnableFly = request.m_IsOn;
                response.Success = true;
                }else if (request.Mode == m_Features::g_Recoil) {
                    NRecoil = request.value;
                    response.Success = true;
                }
                server.sendX((void*)& response, sizeof(response));
            }
        }
    }
    return nullptr;
}


 
 
 //Bypass Aimkill
 
float (*Recoil)(void* _this);
float _Recoil(void* _this) {
    if (_this != NULL) {
     if (NRecoil > 0) {
           return -NRecoil;
    }
    return Recoil(_this);
}
}
bool (*Enough)(void* _this);
bool _Enough(void* _this) {
    if (_this != NULL) {
        return true;
    }
    return Enough(_this);
}
 
uint (*Unlimited_all)(void *_this);
uint _Unlimited_all(void *_this){
    if (_this!= NULL) {
        return 1234567890;
    }
}
uint (*Clan)(void *_this);
uint _Clan(void *_this){
    if (_this!= NULL) {
        return 1234567890;
    }
}
void (*RefreshUserResource)(int Coins,int Gems);
void _RefreshUserResource(int Coins,int Gems){
     _RefreshUserResource(113456789,123456789);
}

/* public bool IsCatapultFalling() { } */

/* public bool IsCatapultFalling() { } */
static bool get_IsCatapultFalling(void *m_catapult){
    bool (*_get_IsCatapultFalling)(void *m_local) = (bool (*)(void *))getAbsoluteAddress(libil2cpp,0xB6F8E4);
    return _get_IsCatapultFalling(m_catapult);
}

static void *OnStopCatapultFalling(void* m_Match) {
    void *(*_OnStopCatapultFalling)(void *match) = (void *(*)(void *))getAbsoluteAddress(libil2cpp,0xBE3724);
    return _OnStopCatapultFalling(m_Match);
}

static void FlyHack(void *local_player, int FlyAltura, int FlySpeed){
    if (EnableFly) {
    Vector3 MountPlayer = Transform_INTERNAL_GetPosition(Component_GetTransform(local_player));
    flysaved.MountCam = Transform_INTERNAL_GetPosition(Component_GetTransform(local_player)) + (GetForward(Component_GetTransform(Camera_main())) * (float)FlySpeed/10.0f);
    if(FlyAltura > 0){
        bool StopCatapult = false;
        if(get_IsCatapultFalling(local_player)){
            if(!StopCatapult){
                StopCatapult = true;
                OnStopCatapultFalling(local_player);
            }
        } else {
            StopCatapult = false;
        }
        if(get_IsSighting(local_player) || get_IsFiring(local_player)){
            Transform_INTERNAL_SetPosition(Component_GetTransform(local_player), Vvector3(flysaved.HaruX, flysaved.HaruY, flysaved.HaruZ));
        } else {
            flysaved.HaruZ = MountPlayer.Z;
            flysaved.HaruX = MountPlayer.X;
            flysaved.HaruY = MountPlayer.Y;
            if(FlyAltura > 1) flysaved.HaruY += (float)FlyAltura/10.0f;
            Transform_INTERNAL_SetPosition(Component_GetTransform(local_player), Vvector3(flysaved.MountCam.X, flysaved.HaruY, flysaved.MountCam.Z));
        }
    }}
}

void (*orig_UpdateBehavior)(void *Player);
void hook_UpdateBehavior(void *Player){
    if (EnableFly) {
    void *LocalPlayer = Current_Local_Player();
    if(LocalPlayer != nullptr && flysaved.Fly){
        FlyHack(LocalPlayer, flysaved.Fly, flysaved.FlySpeed);
    }}
    orig_UpdateBehavior(Player);
}

int (*orig_GetPhysXState)(void *Player);
int hook_GetPhysXState(void *Player){
    if (EnableFly) {
    if(flysaved.Fly){
        return 1;
    }}
    return orig_GetPhysXState(Player);
}

bool (*orig_IsJumpCanMove)(void *Player);
bool hook_pIsJumpCanMove(void *Player){
    if (EnableFly) {
    if(flysaved.Fly){
        void *Match = Curent_Match();
        if(Match){
            void *LocalPlayer = GetLocalPlayer(Match);
            if(LocalPlayer){
                if(Player == LocalPlayer){
                    return true;
                }
            }
        }
    }
   }
    return orig_IsJumpCanMove(Player);
}

bool (*orig_IsPoseFallingHigh)(void *Player);
bool hook_IsPoseFallingHigh(void *Player){
    if (EnableFly) {
    if(flysaved.Fly){
        void *Match = Curent_Match();
        if(Match){
            void *LocalPlayer = GetLocalPlayer(Match);
            if(LocalPlayer){
                if(Player == LocalPlayer){
                    return true;
                }
            }
        }
    }}
    return orig_IsPoseFallingHigh(Player);
}

bool (*orig_IsIgnoreHighFalling)(void *Player);
bool hook_IsIgnoreHighFalling(void *Player){
    if (EnableFly) {
    if(flysaved.Fly){
        void *Match = Curent_Match();
        if(Match){
            void *LocalPlayer = GetLocalPlayer(Match);
            if(LocalPlayer){
                if(Player == LocalPlayer){
                    return true;
                }
            }
        }
    }}
    return orig_IsIgnoreHighFalling(Player);
}

bool (*orig_InFallingState)(void *Player);
bool hook_InFallingState(void *Player){
    if (EnableFly) {
    if(flysaved.Fly){
        void *Match = Curent_Match();
        if(Match){
            void *LocalPlayer = GetLocalPlayer(Match);
            if(LocalPlayer){
                if(Player == LocalPlayer){
                    return true;
                }
            }
        }
      }
  }
    return orig_InFallingState(Player);
}

float (*orig_GetGravity)(void *Player);
float hook_GetGravity(void *Player){
    if (EnableFly) {
    if(flysaved.Fly){
        return -9999.0f;
    }
   }
    return orig_GetGravity(Player);
}

//GOOD BYPASS
void* Thread (void *) {
   // write_file("/storage/emulated/0/Android/GodsTeam.ini","m_CheatStatus01");
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap("libil2cpp.so");
        sleep(1);
    } while (!il2cppMap.isValid());
            // FORCE CLOSE
      //     MemoryPatch("libil2cpp.so", 0x2140288 + 116, "00 F0 20 E3", 4).Modify();
        MemoryPatch("libil2cpp.so", 0x2976C94 + 136, "00 F0 20 E3", 4).Modify();
            //BYPASS OFFSET
	        hexPatches.b1 = MemoryPatch("libil2cpp.so", 0x287F6D8,  "\x00\xF0\x20\xE3", 4);
            hexPatches.b2 = MemoryPatch("libil2cpp.so", 0x38532F8, "\x00\x00\x00\x00", 4);
            hexPatches.b3 = MemoryPatch("libil2cpp.so", 0x385392C, "\x00\x00\x00\x00", 4);
            hexPatches.b4 = MemoryPatch("libil2cpp.so", 0x3853498, "\x00\x00\x00\x00", 4);
            
            hexPatches.b1.Modify();
            hexPatches.b2.Modify();
            hexPatches.b3.Modify();
            hexPatches.b4.Modify();
            
          MSHookFunction((void *)getAbsoluteAddress(libil2cpp, OBFUSCATE_BNM(0xBA1448)), (void *)_DarkUpdateX, (void **)&DarkUpdateX);//
          MSHookFunction((void *)getAbsoluteAddress(libil2cpp, OBFUSCATE_BNM(0xC05260)), (void *)_get_IsMove, (void **)&get_IsMove);//0x1763D7C,0x1201D68
          MSHookFunction((void *)getAbsoluteAddress(libil2cpp, OBFUSCATE_BNM(0x13131E4)), (void *)hook_PlayerNetwork_TakeDamage, (void **)&orig_PlayerNetwork_TakeDamage);
      
            HOOK(0xF727DC,  _Guest, Guest);
          //  HOOK(0xEEB918,  _Badge, Badge);
HOOK(string2Offset(OBFUSCATE("0xB96520")), hook_UpdateBehavior, orig_UpdateBehavior);
HOOK(string2Offset(OBFUSCATE("0xC05260")), hook_pIsJumpCanMove, orig_IsJumpCanMove);
HOOK(string2Offset(OBFUSCATE("0xBE79C4")), hook_IsIgnoreHighFalling, orig_IsIgnoreHighFalling);
HOOK(string2Offset(OBFUSCATE("0xB6A680")), hook_IsPoseFallingHigh, orig_IsPoseFallingHigh);
HOOK(string2Offset(OBFUSCATE("0xB76CD4")), hook_GetPhysXState, orig_GetPhysXState);
HOOK(string2Offset(OBFUSCATE("0xB67A30")), hook_InFallingState, orig_InFallingState);
HOOK(string2Offset(OBFUSCATE("0x24CDBCC")), hook_GetGravity, orig_GetGravity);
HOOK(0x24E11D0,_Recoil,Recoil);
HOOK(0x24DEBE0,_GetRunSpeed,GetRunSpeed);
//hexPatches.Speed100x = MemoryPatch("libunity.so",  0x36FB04, "\x20\x10\x35\x3E", 4);
//hexPatches.Stone = MemoryPatch("libunity.so", (0xD1F8128), "\xC9\x3C\x8E\xBF", 4);//1.90
hexPatches.MedkitRun1 = MemoryPatch::createWithHex("libil2cpp.so", 0xBA0B18, "00 00 A0 E3 1E FF 2F E1", 8);//1.90
hexPatches.MedkitRun2 = MemoryPatch::createWithHex("libil2cpp.so", 0x1DBC5CC, "00 00 A0 E3 1E FF 2F E1", 8);//1.90
//hexPatches.DoubleGun = MemoryPatch::createWithHex("libil2cpp.so", 0x2280184, "02 00 A0 E3 1E FF 2F E1", 8);//1.90
//hexPatches.Night = MemoryPatch("libil2cpp.so", 0x1EBD728, "\x03\x00\xA0\xE3\x1E\xFF\x2F\xE1", 4);
hexPatches.cameraview1 = MemoryPatch::createWithHex("libil2cpp.so", 0x14B708C, "32 00 44 E3 1E FF 2F E1", 8);//---1.90
hexPatches.cameraview2 = MemoryPatch::createWithHex("libil2cpp.so", 0x14B708C, "64 00 44 E3 1E FF 2F E1", 8);//-----1.90
hexPatches.cameraview3 = MemoryPatch::createWithHex("libil2cpp.so", 0x14B708C, "7F 00 44 E3 1E FF 2F E1", 8);//---1.90
hexPatches.cameraview4 = MemoryPatch::createWithHex("libil2cpp.so", 0x14B708C, "C8 00 44 E3 1E FF 2F E1", 8);//---1.90
hexPatches.cameraview5 = MemoryPatch::createWithHex("libil2cpp.so", 0x14B708C, "FA 00 44 E3 1E FF 2F E1", 8);//-----1.90
hexPatches.cameraview6 = MemoryPatch::createWithHex("libil2cpp.so", 0x14B708C, "99 01 44 E3 1E FF 2F E1", 8);//---1.90
//hexPatches.WallHack = MemoryPatch("libunity.so", 0xaedd04, "\x00\x00\xA0\xC0", 4);
hexPatches.Ghost = MemoryPatch("libil2cpp.so", 0x197B10C, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1",8);//1.90

    return NULL;
}


__attribute__((constructor))
void lib_main() {
    pthread_t PidThread;
    pthread_create(&PidThread, NULL, Thread, NULL);
    pthread_t ptid;
   pthread_create(&ptid, nullptr, CreateServer, nullptr);
  
}


